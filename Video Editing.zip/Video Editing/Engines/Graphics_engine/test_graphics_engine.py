from __future__ import annotations

import copy
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from html.parser import HTMLParser
from pathlib import Path


ENGINE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(ENGINE_DIR))

import compose  # noqa: E402
from planner import (  # noqa: E402
    build_clauses,
    discover_assets,
    normalize_words,
    plan_graphics,
    validate_plan,
)


def timed_words(text: str, step: float = 0.27, word_duration: float = 0.20):
    words = []
    time = 0.0
    for token in text.split():
        words.append({"text": token, "start": round(time, 3), "end": round(time + word_duration, 3)})
        time += step
    return words, time + 0.4


class MediaParentParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.stack = []
        self.media_parents = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in {"video", "audio"}:
            self.media_parents.append((attrs.get("id"), self.stack[-1] if self.stack else None, attrs))
        if tag not in {"meta", "link", "img", "source", "br", "hr", "input"}:
            self.stack.append((tag, attrs.get("id")))

    def handle_endtag(self, tag):
        if self.stack and self.stack[-1][0] == tag:
            self.stack.pop()


REFERENCE_LIKE_SCRIPT = (
    "Most people think having ideas is easy . "
    "But the important thing is how clever you are at testing them . "
    "First collect ten ideas , then test 3 prototypes . "
    "Because distribution decides whether your podcast grows ."
)


class TranscriptPlanningTests(unittest.TestCase):
    def test_normalizes_whisperx_and_hyperframes_word_keys(self):
        data = {
            "segments": [
                {"words": [
                    {"word": "A", "start": 0.0, "end": 0.2},
                    {"text": "test.", "start": 0.22, "end": 0.5},
                ]}
            ]
        }
        words = normalize_words(data)
        self.assertEqual([word.text for word in words], ["A", "test."])
        self.assertEqual([word.index for word in words], [0, 1])

    def test_clause_grouping_uses_punctuation_and_pauses(self):
        data = [
            {"text": "One", "start": 0.0, "end": 0.2},
            {"text": "idea.", "start": 0.25, "end": 0.55},
            {"text": "Another", "start": 1.2, "end": 1.4},
            {"text": "works", "start": 1.45, "end": 1.7},
            {"text": "because", "start": 1.75, "end": 2.0},
            {"text": "timing", "start": 2.05, "end": 2.3},
            {"text": "matters.", "start": 2.35, "end": 2.7},
        ]
        clauses = build_clauses(normalize_words(data))
        self.assertEqual([clause.text for clause in clauses], ["One idea.", "Another works because timing matters."])

    def test_number_graphic_is_anchored_to_the_exact_number_word(self):
        words, duration = timed_words("We tested 3 prototypes and learned fast .")
        plan = plan_graphics(words, duration=duration, platform="reels", niche="tech")
        stat = next(cue for cue in plan.cues if cue.graphic_type == "stat")
        self.assertEqual(stat.anchor_word, "3")
        self.assertAlmostEqual(stat.anchor_sec, round(round(words[2]["start"] * 30) / 30, 4))
        self.assertLessEqual(stat.start_sec, stat.anchor_sec)
        self.assertLess(stat.anchor_sec, stat.end_sec)

    def test_reference_rhythm_rotates_speaker_and_graphic_led_states(self):
        words, duration = timed_words(REFERENCE_LIKE_SCRIPT)
        plan = plan_graphics(words, duration=duration, platform="reels", niche="podcast")
        layouts = [cue.layout for cue in plan.cues]
        self.assertIn("stage_pip", layouts)
        self.assertTrue(any(layout in layouts for layout in ("full_stage", "side_panel", "overlay")))
        self.assertTrue(any(cue.speaker_shape == "circle" for cue in plan.cues))
        self.assertTrue(all(cue.duration <= 3.8 + 1e-4 for cue in plan.cues))
        self.assertFalse([issue for issue in plan.qa if issue["severity"] == "error"])

    def test_planning_is_byte_stable_for_identical_inputs(self):
        words, duration = timed_words(REFERENCE_LIKE_SCRIPT)
        first = plan_graphics(words, duration=duration, platform="shorts", niche="education")
        second = plan_graphics(words, duration=duration, platform="shorts", niche="education")
        self.assertEqual(
            json.dumps(first.to_dict(), sort_keys=True, separators=(",", ":")),
            json.dumps(second.to_dict(), sort_keys=True, separators=(",", ":")),
        )

    def test_caption_region_is_reserved_for_every_graphic(self):
        words, duration = timed_words(REFERENCE_LIKE_SCRIPT)
        plan = plan_graphics(words, duration=duration, platform="tiktok", niche="tech", captions_enabled=True)
        caption = plan.safe_areas["captions"]
        caption_top = caption["y"]
        for cue in plan.cues:
            self.assertLessEqual(cue.graphic_bounds.bottom + 16, caption_top)

    def test_rejects_overlapping_words_and_words_ending_after_composition(self):
        with self.assertRaisesRegex(ValueError, "must not overlap"):
            normalize_words([
                {"text": "one", "start": 0.0, "end": 0.5},
                {"text": "two", "start": 0.4, "end": 0.7},
            ])
        with self.assertRaisesRegex(ValueError, "beyond composition duration"):
            plan_graphics(
                [{"text": "late", "start": 0.8, "end": 1.1}],
                duration=1.0,
            )

    def test_platform_safe_areas_use_caption_engine_fractions_at_custom_and_2x_sizes(self):
        expected = {
            "reels": (0.10, 0.18, 0.20, 0.07),
            "tiktok": (0.11, 0.19, 0.23, 0.07),
            "shorts": (0.09, 0.17, 0.18, 0.07),
            "youtube": (0.06, 0.06, 0.11, 0.06),
            "x": (0.07, 0.08, 0.14, 0.08),
        }
        caption_heights = {
            "reels": 300 / 1920,
            "tiktok": 310 / 1920,
            "shorts": 300 / 1920,
            "youtube": 150 / 1080,
            "x": 210 / 1350,
        }
        words, _ = timed_words("A clear system works because timing matters .")
        for platform, (top, right, bottom, left) in expected.items():
            for width, height in ((2160, 3840), (1440, 2560)):
                plan = plan_graphics(words, duration=height / 100.0, platform=platform, width=width, height=height)
                ui = plan.safe_areas["platformUI"]
                self.assertEqual(ui["top"], round(height * top))
                self.assertEqual(ui["right"], round(width * right))
                self.assertEqual(ui["bottom"], round(height * bottom))
                self.assertEqual(ui["left"], round(width * left))
                self.assertEqual(ui["fractions"], {"top": top, "right": right, "bottom": bottom, "left": left})
                captions = plan.safe_areas["captions"]
                caption_height = round(height * caption_heights[platform])
                self.assertEqual(captions["x"], round(width * left))
                self.assertEqual(captions["width"], width - round(width * left) - round(width * right))
                self.assertEqual(captions["height"], caption_height)
                self.assertEqual(captions["y"], height - round(height * bottom) - caption_height)
                self.assertEqual(plan.safe_areas["captionPolicy"]["heightFraction"], caption_heights[platform])

    def test_stat_measure_requires_truthful_parseable_proportion(self):
        count_words, count_duration = timed_words("We tested 3 prototypes and learned quickly .")
        count_plan = plan_graphics(count_words, duration=count_duration)
        count_stat = next(cue for cue in count_plan.cues if cue.graphic_type == "stat")
        self.assertNotIn("proportion", count_stat.content)
        self.assertNotIn('class="measure"', compose.build_composition(count_plan))

        percent_words, percent_duration = timed_words("Retention reached 72% after the redesign .")
        percent_plan = plan_graphics(percent_words, duration=percent_duration)
        percent_stat = next(cue for cue in percent_plan.cues if cue.graphic_type == "stat")
        self.assertEqual(percent_stat.content["proportion"], 0.72)
        page = compose.build_composition(percent_plan)
        self.assertIn('data-proportion="0.72"', page)
        self.assertIn("scaleX:0.72", page)


class AssetSelectionTests(unittest.TestCase):
    def test_catalog_is_visual_only_and_memes_are_opt_in(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "images").mkdir()
            (root / "Memes").mkdir()
            (root / "audio").mkdir()
            (root / "images" / "idea-lightbulb.png").write_bytes(b"png")
            (root / "Memes" / "idea-joke.mp4").write_bytes(b"video")
            (root / "audio" / "idea.mp3").write_bytes(b"audio")
            clean = discover_assets([root])
            all_assets = discover_assets([root], allow_memes=True)
            self.assertEqual([Path(asset.path).name for asset in clean], ["idea-lightbulb.png"])
            self.assertEqual({Path(asset.path).name for asset in all_assets}, {"idea-lightbulb.png", "idea-joke.mp4"})

    def test_semantically_matching_asset_is_selected_and_staged(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "podcast-microphone.png"
            source.write_bytes(b"png")
            words, duration = timed_words("This podcast is the product people remember .")
            plan = plan_graphics(words, duration=duration, platform="reels", niche="podcast", asset_dirs=[root])
            selected = [cue for cue in plan.cues if cue.asset_path]
            self.assertTrue(selected)
            with tempfile.TemporaryDirectory() as project:
                paths = compose.write_project(plan, project)
                self.assertTrue(paths["index"].exists())
                self.assertTrue((Path(project) / "assets" / f"{selected[0].id}.png").exists())

    @unittest.skipUnless(shutil.which("ffmpeg") and (shutil.which("npx") or shutil.which("npx.cmd")),
                         "ffmpeg and npx are required for the real-media lint regression")
    def test_real_mp4_asset_is_root_managed_timed_media_and_hyperframes_lints(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            asset = root / "podcast-studio.mp4"
            result = subprocess.run([
                shutil.which("ffmpeg"), "-y", "-f", "lavfi", "-i",
                "testsrc2=size=96x96:rate=30", "-t", "1.0", "-an",
                "-c:v", "libx264", "-pix_fmt", "yuv420p", str(asset),
            ], capture_output=True, text=True, encoding="utf-8", errors="replace")
            self.assertEqual(result.returncode, 0, result.stderr)
            words, duration = timed_words("This podcast product is easy to remember .")
            plan = plan_graphics(words, duration=duration, platform="reels", niche="podcast", asset_dirs=[root])
            selected = next(cue for cue in plan.cues if cue.asset_path)
            # npx can briefly retain its cwd on Windows after the lint process
            # reports completion; do not turn that OS cleanup race into a test
            # failure after the actual regression assertions have passed.
            with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as project:
                paths = compose.write_project(plan, project)
                staged = Path(project) / "assets" / f"{selected.id}.mp4"
                self.assertTrue(staged.exists())
                page = paths["index"].read_text(encoding="utf-8")
                parser = MediaParentParser()
                parser.feed(page)
                asset_media = next(item for item in parser.media_parents if item[0] == f"asset-video-{selected.id}")
                self.assertEqual(asset_media[1], ("main", "stage"))
                self.assertIn("data-start", asset_media[2])
                self.assertIn("data-duration", asset_media[2])
                self.assertIn("data-track-index", asset_media[2])
                self.assertNotIn('<div class="asset-frame"><video', page)
                compose.lint(project)


class CompositionContractTests(unittest.TestCase):
    def make_plan(self):
        words, duration = timed_words(REFERENCE_LIKE_SCRIPT)
        return plan_graphics(words, duration=duration, platform="reels", niche="tech")

    def test_generated_page_is_offline_seek_safe_and_hyperframes_shaped(self):
        plan = self.make_plan()
        page = compose.build_composition(plan)
        self.assertIn('src="vendor/gsap.min.js"', page)
        self.assertNotIn("https://", page)
        self.assertNotIn("http://", page)
        self.assertIn("gsap.timeline({paused:true})", page)
        self.assertIn("window.__timelines['graphics-main']", page)
        self.assertIn('data-composition-id="graphics-main"', page)
        self.assertIn('class="graphic-card clip', page)
        self.assertNotIn("Math.random", page)
        self.assertNotIn("Date.now", page)
        self.assertNotIn("repeat:-1", page.replace(" ", ""))
        self.assertNotIn("back.out", page)

    def test_packaged_video_declares_audio_and_uses_one_managed_media_track(self):
        plan = self.make_plan()
        page = compose.build_composition(plan, source_ref="media/source-video.mp4")
        self.assertEqual(page.count('id="source-video"'), 1)
        self.assertEqual(page.count('id="source-audio"'), 1)
        self.assertIn('data-track-index="0"', page)
        self.assertIn('data-track-index="10"', page)
        self.assertIn('muted playsinline', page)
        self.assertNotIn("video-wrap", page)
        self.assertNotRegex(page, r"tl\.(?:to|fromTo)\([^\n]+(?:left|top|width|height)")
        parser = MediaParentParser()
        parser.feed(page)
        self.assertTrue(parser.media_parents)
        self.assertTrue(all(parent == ("main", "stage") for _, parent, _ in parser.media_parents))

    def test_project_stages_local_runtime_fonts_plan_and_qa(self):
        plan = self.make_plan()
        with tempfile.TemporaryDirectory() as tmp:
            paths = compose.write_project(plan, tmp)
            self.assertTrue((Path(tmp) / "vendor" / "gsap.min.js").exists())
            self.assertTrue((Path(tmp) / "fonts" / "Inter-400-latin.woff2").exists())
            self.assertTrue(paths["index"].exists())
            self.assertTrue(paths["plan"].exists())
            qa = json.loads(paths["qa"].read_text(encoding="utf-8"))
            self.assertTrue(qa["automatedChecksPassed"])
            self.assertFalse(qa["readiness"]["readyForDelivery"])
            self.assertEqual(qa["readiness"]["status"], "review-required")
            self.assertEqual(
                {review["status"] for review in qa["readiness"]["requiredReviews"]},
                {"pending"},
            )

    def test_trigger_specific_reveal_is_scheduled_to_finish_by_anchor(self):
        plan = self.make_plan()
        stat = next(cue for cue in plan.cues if cue.graphic_type == "stat")
        timeline = compose._card_timeline(stat)
        reveal_duration = min(0.36, max(0.06, stat.anchor_sec - stat.start_sec))
        reveal_at = max(stat.start_sec, stat.anchor_sec - reveal_duration)
        self.assertLessEqual(reveal_at + reveal_duration, stat.anchor_sec + 1e-6)
        self.assertIn(f"duration:{compose._fmt(reveal_duration)}", timeline)

    def test_unverified_speaker_crop_is_metadata_and_warning(self):
        words, duration = timed_words(REFERENCE_LIKE_SCRIPT)
        plan = plan_graphics(
            words, duration=duration, platform="reels", niche="podcast",
            source_video="speaker.mp4",
        )
        cropped = [cue for cue in plan.cues if cue.speaker_bounds]
        self.assertTrue(cropped)
        self.assertTrue(all(cue.speaker_crop_status == "unverified" for cue in cropped))
        self.assertEqual(plan.composition["speakerCropVerification"]["status"], "unverified")
        self.assertIn("speaker_crop_unverified", {issue["code"] for issue in plan.qa})

    def test_legacy_title_card_keeps_api_but_uses_offline_runtime(self):
        page = compose.title_card("ARETE", subtitle="Agentic OS", duration=2.5)
        self.assertIn("ARETE", page)
        self.assertIn("Agentic OS", page)
        self.assertIn('src="vendor/gsap.min.js"', page)
        self.assertNotIn("cdn.jsdelivr", page)
        self.assertIn("paused:true", page)

    def test_qa_rejects_overlap(self):
        plan = self.make_plan()
        self.assertGreaterEqual(len(plan.cues), 2)
        broken = copy.deepcopy(plan)
        broken.cues[1].start_sec = broken.cues[0].start_sec
        issues = validate_plan(broken)
        self.assertIn("cue_overlap", {issue["code"] for issue in issues})


if __name__ == "__main__":
    unittest.main()
