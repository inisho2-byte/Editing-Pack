"""Production caption engine CLI.

Audio or aligned words -> semantic caption plan -> ARETE ASS + HyperFrames JSON
+ a machine-readable QA report.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

import align
import emit
import validate
from phrasing import Config, PLATFORM_DEFAULTS, segment_words


def _atomic_write(path, content):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="\n", delete=False, dir=path.parent,
        prefix=f".{path.name}.", suffix=".tmp",
    )
    try:
        with handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(handle.name, path)
    except Exception:
        try:
            os.unlink(handle.name)
        except OSError:
            pass
        raise


def _remove_render_artifacts(*paths):
    """Remove renderable artifacts before publishing a failing strict QA report."""
    for path in paths:
        try:
            Path(path).unlink()
        except FileNotFoundError:
            pass


def load_words_json(path):
    """Load aligned words from a list, ``{words}``, or Whisper-style segments."""
    with open(path, encoding="utf-8") as handle:
        data = json.load(handle)
    if isinstance(data, list):
        words = data
    elif isinstance(data, dict) and isinstance(data.get("words"), list):
        words = data["words"]
    elif isinstance(data, dict) and isinstance(data.get("segments"), list):
        words = [
            word
            for segment in data["segments"]
            for word in segment.get("words", [])
        ]
    else:
        raise align.AlignmentError(
            "words JSON must be a word list, {'words': [...]}, or {'segments': [...]}"
        )
    return align.normalize_words(words, source="provided-aligned")


def run(
    audio=None,
    out_prefix="captions",
    script=None,
    model="base",
    backend="auto",
    playres=(1080, 1920),
    cfg=None,
    words=None,
    platform=None,
    style_overrides=None,
    strict=True,
):
    """Build all caption artifacts and return the semantic segments.

    ``words`` is the deterministic integration path for an upstream WhisperX
    stage.  Supplying it bypasses transcription but not normalization, optional
    corrected-script mapping, phrasing, style selection or QA.
    """
    if cfg is None:
        cfg = Config.for_platform(platform or "instagram-reels")
    elif platform and platform != cfg.platform:
        cfg = cfg.with_overrides(platform=platform)

    if words is None:
        if not audio:
            raise align.AlignmentError("audio or pre-aligned words are required")
        words = align.transcribe_words(audio, model=model, backend=backend)
    else:
        words = align.normalize_words(words, source="provided-aligned")

    if script:
        with open(script, encoding="utf-8") as handle:
            words = align.force_align_to_script(words, handle.read())

    segments = segment_words(words, cfg)
    profile = emit.get_style_profile(cfg.platform, playres, style_overrides)
    report = validate.build_qa_report(words, segments, cfg, profile)
    report["source_fingerprint"] = emit.source_fingerprint(segments, cfg, profile)

    ass_path = f"{out_prefix}.ass"
    json_path = f"{out_prefix}.captions.json"
    qa_path = f"{out_prefix}.qa.json"
    if strict and report["summary"]["errors"]:
        # A QA report describes one source fingerprint. Never leave older ASS or
        # JSON outputs beside it where an orchestrator could consume stale work.
        _remove_render_artifacts(ass_path, json_path)
        _atomic_write(qa_path, validate.dumps_report(report))
        validate.raise_for_errors(report)
    _atomic_write(qa_path, validate.dumps_report(report))

    ass_text = emit.to_ass(segments, cfg, playres, profile=profile)
    hyperframes = emit.to_hyperframes(segments, cfg, playres, profile=profile)
    hyperframes["qa"] = report["summary"]
    hyperframes_text = json.dumps(
        hyperframes, indent=2, ensure_ascii=False, sort_keys=True
    ) + "\n"
    _atomic_write(ass_path, ass_text)
    _atomic_write(json_path, hyperframes_text)

    print(
        f"words: {len(words)}  segments: {len(segments)}  "
        f"qa: {report['status']} ({report['summary']['warnings']} warnings)"
    )
    print(f"wrote: {ass_path}")
    print(f"wrote: {json_path}")
    print(f"wrote: {qa_path}")
    return segments


def _parser():
    parser = argparse.ArgumentParser(
        description="Word-aligned, semantic caption engine (ASS + HyperFrames + QA)."
    )
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--audio", help="input audio/video file")
    source.add_argument(
        "--words-json", help="pre-aligned word JSON from WhisperX/another forced aligner"
    )
    parser.add_argument(
        "--script", help="corrected script text to remap onto audio timings (names/terminology)"
    )
    parser.add_argument("--out-prefix", default="captions", help="output path prefix")
    parser.add_argument("--model", default="base", help="Whisper model name")
    parser.add_argument(
        "--backend", default="auto", choices=["auto", "whisperx", "whisper"],
        help=(
            "alignment backend: auto/whisperx require forced alignment; raw "
            "Whisper timestamps are lower-confidence and must be requested explicitly"
        ),
    )
    parser.add_argument(
        "--platform", default="instagram-reels", choices=sorted(PLATFORM_DEFAULTS),
        help="platform-native density, motion and safe-area profile",
    )
    parser.add_argument("--width", type=int, default=1080)
    parser.add_argument("--height", type=int, default=1920)
    parser.add_argument("--max-chars", type=int, help="maximum characters per visual line")
    parser.add_argument("--max-words", type=int, help="maximum words per semantic caption")
    parser.add_argument("--max-dur", type=float, help="maximum spoken span per caption")
    parser.add_argument("--min-dur", type=float, help="minimum on-screen exposure")
    parser.add_argument(
        "--reading-behavior", choices=["auto", "full-reading", "skimming", "glancing"],
        default="auto",
    )
    parser.add_argument("--font", help="ASS/HyperFrames font-family override")
    parser.add_argument(
        "--font-size", type=float,
        help="font size at a 1080px short-edge reference (portrait or landscape)",
    )
    parser.add_argument("--accent", help="meaning-word accent as #RRGGBB")
    parser.add_argument(
        "--allow-qa-errors", action="store_true",
        help="write render artifacts despite QA errors (QA report is always written)",
    )
    parser.add_argument("--print-profiles", action="store_true", help="list platform profiles and exit")
    parser.add_argument("--selftest", action="store_true", help="run pure-Python tests and exit")
    return parser


def main(argv=None):
    parser = _parser()
    args = parser.parse_args(argv)

    if args.selftest:
        import test_engine

        return test_engine.run_all()
    if args.print_profiles:
        for platform in sorted(PLATFORM_DEFAULTS):
            profile = emit.STYLE_PROFILES[platform]
            print(f"{platform:18} {profile['name']:27} {profile['density']}")
        return 0
    if not args.audio and not args.words_json:
        parser.error("--audio or --words-json is required (or use --selftest/--print-profiles)")

    cfg = Config.for_platform(
        args.platform,
        max_chars_per_line=args.max_chars,
        max_words_per_caption=args.max_words,
        max_caption_dur=args.max_dur,
        min_caption_dur=args.min_dur,
        reading_behavior=args.reading_behavior,
    )
    style_overrides = {
        "font": args.font,
        "font_size": args.font_size,
        "accent": args.accent,
    }
    try:
        words = load_words_json(args.words_json) if args.words_json else None
        run(
            audio=args.audio,
            out_prefix=args.out_prefix,
            script=args.script,
            model=args.model,
            backend=args.backend,
            playres=(args.width, args.height),
            cfg=cfg,
            words=words,
            style_overrides=style_overrides,
            strict=not args.allow_qa_errors,
        )
    except (align.AlignmentError, validate.CaptionValidationError, ValueError) as exc:
        print(f"caption engine: {exc}", file=sys.stderr)
        if isinstance(exc, validate.CaptionValidationError):
            print("See the .qa.json report for exact failures.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
