---
title: "Video Editing Engine"
category: engine
last_updated: 2026-07-12
tags: [video-editing, editorial, edl, ffmpeg, qa]
---

# Video Editing Engine

The editorial decision and render layer for the ARETE Editing OS. It turns
verbatim word timestamps into a reviewable edit, then renders only the EDL the
human approved. The engine optimizes attention through subtraction and timing;
it does not compensate for weak story with mechanical cuts or template effects.

The existing single-clip grade/caption API still works. The v2 workflow adds:

- dead-air compression with an intentional-pause escape hatch;
- filler, stumble, false-start, and repeated-take cleanup;
- review-only flags for lower-confidence semantic repetition;
- explainable hook and retention scoring;
- meaning-led beat, shot-rhythm, caption, and graphics plans;
- a source-to-output timing map after every cut;
- deterministic EDL validation and a macro-to-micro QA manifest;
- a production-correct ffmpeg path for segments, overlays, captions, audio, and HDR.

## The two-stage safety contract

Planning and execution are separate on purpose.

```text
word-level transcript
  -> analyze + propose
  -> editorial-plan.json + edl.json
  -> human reviews the actual EDL
  -> apply approved EDL
  -> final video + report.json
```

`--plan-edits` never renders. `--apply-edits` requires `--edl-in`; passing that
reviewed artifact is the approval signal. This preserves the Editing OS rule
that strategy is confirmed before the timeline is changed.

## Quick start

Use an existing word-level transcript when available. Accepted JSON shapes are
a word array, `{ "words": [...] }`, Whisper `{ "segments": [{"words": ...}] }`,
or the sibling caption engine's HyperFrames `{ "clips": [{"words": ...}] }`.

```powershell
python engine.py `
  --input raw.mp4 `
  --plan-edits `
  --words-json words.json `
  --platform reels `
  --pacing adaptive `
  --edl-out edit/edl.json `
  --plan-out edit/editorial-plan.json
```

If `--words-json` is omitted, the sibling `Captions_engine` produces word-level
timestamps. A corrected script can be force-aligned during this pass:

```powershell
python engine.py --input raw.mp4 --plan-edits --script script.txt
```

Review `editorial-plan.json`, especially `analysis.review_required`, the hook
candidates, and every range. Then render the approved EDL:

```powershell
python engine.py `
  --apply-edits `
  --edl-in edit/edl.json `
  --out edit/final.mp4
```

`--input` is intentionally not required at apply time: the reviewed EDL freezes
its source paths and is the approval signal. Planning and legacy grade/caption
mode still require `--input`.

To add semantic graphics from the same approved output-timeline words, opt in
on the apply command. The clean-cut source is packaged through the graphics
planner/composer first, then captions are validated and burned last:

```powershell
python engine.py `
  --apply-edits `
  --edl-in edit/edl.json `
  --graphics `
  --graphics-niche tech `
  --graphics-assets-dir assets `
  --out edit/final.mp4
```

The graphics report includes the persisted `graphics-plan.json` and
`graphics-qa.json`. A purposeful zero-cue plan is recorded and skips the
otherwise redundant HyperFrames re-encode. Omit `--graphics` to preserve the
existing captions/overlays-only render path.

## Cleanup policy

The engine distinguishes correctness-like cleanup from semantic judgment.

| Signal | Default action | Why |
|---|---|---|
| Long silence | Compress to a platform/pacing-aware breath | Removes escape points without making speech inhuman |
| `um`, `uh`, `erm` | Remove | Non-lexical hesitation has no message payload |
| `you know`, `I mean`, `kind of`, `sort of` | Remove only when context is safe; otherwise review | These phrases can occasionally carry tone or contrast |
| Broken prefix (`th- the`) | Remove fragment | The completed word preserves the meaning |
| Immediate repeated word/phrase | Remove earlier attempt | Keeps the completed delivery |
| Adjacent near-verbatim take | Keep one stronger take | Duplicate work does not earn runtime |
| Similar but non-identical idea | Review only | Lexical similarity cannot prove semantic redundancy |

Intentional comedic, dramatic, or emotional pauses are preserved when the
transcript marks them with an ellipsis, `[beat]`, `(beat)`, `[pause]`, a
bracketed performance event such as `[laughs]`, or word metadata
`preserve_pause_after` / `preserve_pause_before`.

Cleanup intensity is configurable:

```powershell
--cleanup-strength conservative|balanced|ruthless
--dead-air-threshold 0.45
--breath-pad-before 0.06
--breath-pad-after 0.08
--keep-fillers
--keep-repeated-takes
```

Cut padding is constrained to the ecosystem's verified 30-200ms working
window. If adjacent speech physically leaves less than 30ms, the cut lands on
the word edge and the validator emits `constrained_padding`; it never moves the
edge inside a word to manufacture padding.

## Attention and rhythm planning

The planner scores clauses as explainable triage, not as an opaque claim that a
heuristic understands the story. Hook scoring rewards early promises,
questions, concrete numbers, stakes, and viewer address; it penalizes generic
throat-clearing and slow resolution. Retention scoring reports information
density, novelty, specificity, contrast, repetition, and long unbroken ideas.

If a later clause is materially stronger than the opening, the plan emits a
`hook_opportunity` for review. It does not reorder the argument automatically.

Visual refresh targets adapt to platform and pacing. Reels default to roughly
2.6 seconds, TikTok 2.2, Shorts 2.8, X 3.4, YouTube 5, and documentary 7. These
are attention windows, not metronomes: cues land at clause/idea boundaries and
describe the information shape (`stat_or_number`, `comparison`,
`process_steps`, `mechanism_diagram`, or a motivated refresh). There is no
"alternate treatment every N shots" rule.

The rhythm manifest uses the macro shape:

```text
tight hook -> varied build -> accelerate into peak -> release
```

Every proposed shot carries the hard instruction: cut on meaning first; music
may only nudge a cut within existing silence.

## Downstream timing contract

An edit changes time. The EDL therefore carries one shared mapping for every
downstream engine:

```json
{
  "range_id": "range_...",
  "source": "main",
  "source_start": 2.42,
  "source_end": 6.85,
  "output_start": 0.0,
  "output_end": 4.43,
  "source_to_output_offset": -2.42,
  "word_start_index": 18,
  "word_end_index": 43
}
```

`edl.editorial.timeline_map` is the range-level conversion contract.
`edl.editorial.retimed_words` is the word-level source of truth. Caption and
graphics handoffs use output-timeline seconds exclusively:

- `editorial.handoffs.captions.cues`: one idea, emphasis words, exact window;
- `editorial.handoffs.graphics.cues`: semantic beat, information shape,
  priority, duration, and caption-safe guardrails;
- `editorial.rhythm_plan`: macro phases and meaning-led visual treatments.

The caption engine re-phrases `retimed_words` after approval, so captions stay
word-accurate without a second transcription pass.

Validation reconstructs every retimed word from the approved ranges and the
source-word evidence before render; stale, reordered, or hand-edited timing is
rejected. A multi-source EDL must include
`editorial.source_words_by_source` for every source. The renderer fails closed
instead of guessing which transcript belongs to which file.

## EDL range contract

The renderer-compatible v1 range fields remain intact and additions are
backward-compatible:

```json
{
  "id": "range_...",
  "source": "main",
  "start": 2.36,
  "end": 6.93,
  "grade": "subtle",
  "beat": "HOOK",
  "quote": "The kept delivery.",
  "reason": "Keep semantic content; boundary tightened at verified word/pause edges.",
  "word_boundary_start": "The",
  "word_boundary_end": "delivery.",
  "word_start_index": 18,
  "word_end_index": 43,
  "word_start_s": 2.42,
  "word_end_s": 6.85,
  "pad_in_s": 0.06,
  "pad_out_s": 0.08,
  "decision_ids": ["decision_..."]
}
```

Stable SHA-1-derived IDs make identical input and configuration byte-
deterministic. They are identifiers, not security hashes.

## Render correctness

The approved-EDL path enforces the ecosystem hard rules in code:

1. Validate every range and prove that no edge falls inside a spoken word.
2. Detect PQ (`smpte2084`) or HLG (`arib-std-b67`) and prepend the verified
   Hable BT.709 tone-map before the selected grade.
3. Extract and encode each range once with its grade, 30ms audio fades,
   zero-delay H.264 (`-bf 0`), and PCM audio.
4. Losslessly concatenate those matching Matroska segments with `-c copy`.
   AAC is encoded only once after concatenation, so encoder priming cannot
   accumulate per cut and drift from the shared caption/graphics clock.
5. Shift every overlay with `setpts=PTS-STARTPTS+T/TB` and composite it in its
   declared output window.
6. Apply captions after every overlay, then normalize dialogue to -14 LUFS,
   -1 dBTP, LRA 11.
7. Compare the actual output duration to `edl.total_duration_s` (plus an
   explicitly requested intro), never to the unedited input duration.

The final report records validation, source transfer functions, HDR tone-map
decisions, stage timings, cut count, duration delta, caption artifacts, and the
mandatory visual QA windows.

## Validation and QA

`validate_edl()` rejects:

- missing/unknown sources or malformed ranges;
- range edges inside words;
- incorrect word-boundary labels or containment;
- invalid or duplicate deterministic IDs;
- declared duration that differs from the range sum;
- overlays, caption cues, or graphics cues outside the edited timeline;
- overlapping source word timestamps beyond the 80ms tolerance;
- retimed words that cannot be reconstructed from source evidence;
- multi-source EDLs missing per-source word evidence;
- padding beyond 200ms.

It warns when a neighboring word constrains the preferred 30ms minimum. Final
duration must match the approved EDL within 120ms; the multi-cut regression is
stricter and remains within 30ms.

`editorial.qa_plan` lists every cut with a +/-1.5s inspection window, first/end
and midpoint samples, a macro-to-micro review order, and a three-pass cap. The
automated duration gate does not pretend to replace visual inspection; reports
set `requires_visual_review: true` until those windows have been reviewed.

## Python API

```python
from editorial import EditorialConfig, build_editorial_plan, validate_edl
from engine import apply_edl

config = EditorialConfig(platform="shorts", pacing="adaptive")
plan = build_editorial_plan(
    words,
    source_id="main",
    source_path=r"C:\video\raw.mp4",
    config=config,
)

assert plan["validation"]["valid"]
# Persist/review plan["edl"] before this call.
report = apply_edl(plan["edl"], r"C:\video\final.mp4")
```

`engine.plan_edits()` is the filesystem-oriented equivalent and writes both the
compact EDL and full analysis packet.

## Legacy single-clip mode

Existing commands remain valid and do not make editorial cuts:

```powershell
python engine.py --input in.mp4 --out out.mp4 --grade warm_cinematic
python engine.py --input in.mp4 --script script.txt --out out.mp4
python engine.py --input in.mp4 --out out.mp4 --no-captions --grade subtle
```

The legacy path is retained for grade/caption-only jobs. Use the two-stage EDL
workflow whenever cleanup, pacing, overlays, or downstream timing matter.

## Tests

Pure planning and command-contract tests require no model or source footage:

```powershell
python -m unittest -v test_editorial.py test_apply_integration.py
```

Coverage includes cleanup, intentional pauses, repeated takes, semantic review
flags, hook/retention reasoning, semantic graphics cues, macro rhythm, timeline
retiming, deterministic output, invalid in-word cuts, duration/cue bounds, HDR
filter order, overlay PTS shift, captions-last order, and plan-file emission.
`test_apply_integration.py` adds the approved-EDL graphics/caption handoff,
platform-profile QA, zero-cue behavior, no-input apply CLI, and a real 5-cut
audio-drift regression using a 2.5-second synthetic fixture.

## Related pages

- [[Projects/Personal projects/AI Projects/Video editing tools/Editing_OS/Video Editing/Engines/README|Video Editing OS Engines]]
- [[Projects/Personal projects/AI Projects/Video editing tools/Editing_OS/Video Editing/Engines/Captions_engine/README|Captions Engine]]
- [[Projects/Personal projects/AI Projects/Video editing tools/Editing_OS/Video Editing/Engines/Graphics_engine/README|Graphics Engine]]
