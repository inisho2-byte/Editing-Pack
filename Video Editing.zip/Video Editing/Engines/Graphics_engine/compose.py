"""Deterministic graphics compositor for the Video Editing OS.

Two entry paths are supported:

* ``title_card`` preserves the small legacy API used by the sibling editing
  engine.
* ``plan_graphics`` + ``write_project`` creates a transcript-aware graphics
  package with semantic cards, exact word anchors, varied speaker layouts,
  local assets, a paused master timeline, and a machine-readable QA report.

Captions remain the Captions_engine's responsibility.  This engine reserves
their region and refuses collisions rather than attempting to render them.
"""

from __future__ import annotations

import argparse
import html
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any, Mapping

try:  # Package import when discovered by a test runner.
    from .planner import GraphicCue, GraphicsPlan, assert_plan_valid, plan_graphics
except ImportError:  # Direct ``python compose.py`` and sibling-engine import.
    from planner import GraphicCue, GraphicsPlan, assert_plan_valid, plan_graphics


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


ENGINE_DIR = Path(__file__).resolve().parent
EDITING_OS_DIR = ENGINE_DIR.parents[2]
HYPERFRAMES_SKILL_ASSETS = (
    EDITING_OS_DIR
    / "Tools"
    / "Editing tools"
    / "hyperframes"
    / "skills"
    / "talking-head-recut"
    / "assets"
)


def _fmt(value: float) -> str:
    return f"{value:.4f}".rstrip("0").rstrip(".") or "0"


def _css(value: str) -> str:
    """Allow only plain CSS color/font tokens from the internal theme table."""
    return re_safe(value)


def re_safe(value: str) -> str:
    return "".join(ch for ch in str(value) if ch.isalnum() or ch in "#(),.-_ %'")


def _escape(value: Any) -> str:
    return html.escape(str(value), quote=True)


def _stage_runtime(project_dir: Path) -> None:
    vendor_source = HYPERFRAMES_SKILL_ASSETS / "vendor" / "gsap.min.js"
    font_source = HYPERFRAMES_SKILL_ASSETS / "fonts"
    if not vendor_source.exists():
        raise FileNotFoundError(
            "local GSAP runtime not found; expected the vendored HyperFrames asset at "
            f"{vendor_source}"
        )
    (project_dir / "vendor").mkdir(parents=True, exist_ok=True)
    shutil.copy2(vendor_source, project_dir / "vendor" / "gsap.min.js")
    if font_source.exists():
        (project_dir / "fonts").mkdir(parents=True, exist_ok=True)
        for name in ("Inter-400-latin.woff2", "Inter-700-latin.woff2"):
            source = font_source / name
            if source.exists():
                shutil.copy2(source, project_dir / "fonts" / name)


def _theme_css(theme: Mapping[str, Any]) -> str:
    accents = list(theme.get("accents") or ["#3DD6D0"])
    while len(accents) < 4:
        accents.append(accents[-1])
    return "\n".join(
        [
            f"--bg:{_css(theme.get('background', '#0E151C'))};",
            f"--surface:{_css(theme.get('surface', '#17222C'))};",
            f"--text:{_css(theme.get('text', '#F5F8FA'))};",
            f"--muted:{_css(theme.get('muted', '#A2B0BC'))};",
        ]
        + [f"--accent-{index}:{_css(color)};" for index, color in enumerate(accents[:4])]
    )


def _asset_markup(cue: GraphicCue, asset_ref: str | None) -> str:
    if not asset_ref:
        return ""
    suffix = Path(asset_ref).suffix.lower()
    ref = _escape(asset_ref.replace("\\", "/"))
    if suffix in {".mp4", ".mov", ".mkv", ".webm", ".m4v"}:
        # HyperFrames media must be a direct composition-root child.  Video
        # assets are emitted separately by _asset_video_markup(); the card
        # retains only its frame/shade/copy shell.
        return ""
    return f'<img class="asset-media" src="{ref}" alt="" />'


def _is_video_ref(asset_ref: str | None) -> bool:
    return bool(asset_ref and Path(asset_ref).suffix.lower() in {".mp4", ".mov", ".mkv", ".webm", ".m4v"})


def _card_inner(cue: GraphicCue, asset_ref: str | None) -> str:
    headline = _escape(cue.headline)
    detail = _escape(cue.detail)
    accent = cue.accent_index % 4
    kicker = _escape(cue.graphic_type.replace("_", " ").upper())

    if cue.graphic_type == "stat":
        value = _escape(cue.content.get("value", cue.headline))
        label = _escape(cue.content.get("label", cue.detail))
        proportion = cue.content.get("proportion")
        measure = ""
        if isinstance(proportion, (int, float)) and 0 <= float(proportion) <= 1:
            measure = (
                f'<div class="measure" data-proportion="{_fmt(float(proportion))}">'
                f'<i style="--measure-proportion:{_fmt(float(proportion))}"></i></div>'
            )
        return f"""
          <div class="kicker"><span></span>{kicker}</div>
          <div class="stat-value">{value}</div>
          <div class="stat-label">{label}</div>
          {measure}
        """
    if cue.graphic_type == "comparison":
        left = _escape(cue.content.get("left", "Current"))
        right = _escape(cue.content.get("right", "Better"))
        return f"""
          <div class="kicker"><span></span>COMPARE</div>
          <div class="comparison-grid">
            <div class="comparison-side" data-side="left"><small>01</small><strong>{left}</strong></div>
            <div class="comparison-axis"><i></i><b>→</b></div>
            <div class="comparison-side is-accent" data-side="right"><small>02</small><strong>{right}</strong></div>
          </div>
        """
    if cue.graphic_type == "process":
        steps = list(cue.content.get("steps") or [])[:3]
        step_markup = "".join(
            f'<div class="process-step"><b>{index + 1:02d}</b><span>{_escape(step)}</span></div>'
            for index, step in enumerate(steps)
        )
        return f"""
          <div class="kicker"><span></span>PROCESS</div>
          <h2>{headline}</h2>
          <div class="process-line">{step_markup}</div>
        """
    if cue.graphic_type == "concept_diagram":
        center = _escape(cue.content.get("center", cue.anchor_word))
        nodes = list(cue.content.get("nodes") or [])[:3]
        node_markup = "".join(
            f'<div class="diagram-node node-{index + 1}">{_escape(node)}</div>'
            for index, node in enumerate(nodes)
        )
        return f"""
          <div class="kicker"><span></span>IDEA MAP</div>
          <div class="diagram">
            <svg viewBox="0 0 600 420" aria-hidden="true">
              <path d="M300 210 C215 190 180 116 104 88" />
              <path d="M300 210 C400 190 430 105 510 94" />
              <path d="M300 210 C315 292 390 324 468 345" />
            </svg>
            <div class="diagram-center">{center}</div>{node_markup}
          </div>
          <h2 class="diagram-title">{headline}</h2>
        """
    if cue.graphic_type == "quote":
        return f"""
          <div class="quote-mark">“</div>
          <blockquote>{headline}</blockquote>
          <div class="quote-rule"></div>
        """
    if cue.graphic_type == "asset_focus":
        media = _asset_markup(cue, asset_ref)
        return f"""
          <div class="asset-frame">{media}<div class="asset-shade"></div></div>
          <div class="asset-copy" data-layout-allow-occlusion="true"><div class="kicker"><span></span>{kicker}</div><h2>{headline}</h2></div>
        """
    emphasis = _escape(cue.content.get("emphasis", ""))
    return f"""
      <div class="kicker"><span></span>{kicker}</div>
      <h2 class="keyword-title">{headline}</h2>
      <div class="keyword-rule"><i></i></div>
      {f'<div class="meaning-chip">{emphasis}</div>' if emphasis else ''}
    """


def _card_markup(cue: GraphicCue, asset_ref: str | None = None) -> str:
    bounds = cue.graphic_bounds
    media_class = " has-host-video" if _is_video_ref(asset_ref) else ""
    return f"""
      <section id="{_escape(cue.id)}" class="graphic-card clip type-{_escape(cue.graphic_type)} layout-{_escape(cue.layout)}{media_class}"
        data-start="{_fmt(cue.start_sec)}" data-duration="{_fmt(cue.duration)}" data-track-index="3"
        data-anchor="{_fmt(cue.anchor_sec)}" data-anchor-word="{_escape(cue.anchor_word)}"
        style="left:{bounds.x}px;top:{bounds.y}px;width:{bounds.width}px;height:{bounds.height}px;--cue-accent:var(--accent-{cue.accent_index % 4});">
        <div class="graphic-shell">{_card_inner(cue, asset_ref)}</div>
      </section>
    """


def _card_timeline(cue: GraphicCue) -> str:
    selector = json.dumps(f"#{cue.id}")
    start = cue.start_sec
    anchor = max(cue.start_sec, cue.anchor_sec)
    end = cue.end_sec
    lead = max(0.0, anchor - start)
    enter = min(0.34, max(0.06, lead - 0.08))
    shell_at = max(start, anchor - enter - 0.06)
    exit_duration = min(0.30, max(0.18, cue.duration * 0.12))
    exit_at = max(start + enter, end - exit_duration)
    lines = [
        f"tl.fromTo({selector} + ' .graphic-shell', {{opacity:0, y:22}}, "
        f"{{opacity:1, y:0, duration:{_fmt(enter)}, ease:'power3.out'}}, {_fmt(shell_at)});",
    ]
    if cue.graphic_type == "stat":
        reveal_duration = min(0.36, max(0.06, lead))
        reveal_at = max(start, anchor - reveal_duration)
        lines.append(
            f"tl.fromTo({selector} + ' .stat-value', {{opacity:0, y:28}}, "
            f"{{opacity:1, y:0, duration:{_fmt(reveal_duration)}, ease:'power3.out'}}, {_fmt(reveal_at)});"
        )
        proportion = cue.content.get("proportion")
        if isinstance(proportion, (int, float)) and 0 <= float(proportion) <= 1:
            measure_duration = min(0.34, max(0.06, lead))
            measure_at = max(start, anchor - measure_duration)
            lines.append(
                f"tl.fromTo({selector} + ' .measure i', {{scaleX:0}}, "
                f"{{scaleX:{_fmt(float(proportion))}, duration:{_fmt(measure_duration)}, ease:'power2.inOut'}}, {_fmt(measure_at)});"
            )
    elif cue.graphic_type == "comparison":
        reveal_at = max(start, anchor - min(0.36, lead))
        lines.append(
            f"tl.fromTo({selector} + ' .comparison-side', {{opacity:0, y:18}}, "
            f"{{opacity:1, y:0, duration:.30, stagger:.06, ease:'power3.out'}}, {_fmt(reveal_at)});"
        )
        lines.append(
            f"tl.fromTo({selector} + ' .comparison-axis i', {{scaleY:0}}, {{scaleY:1, duration:.34, ease:'power2.inOut'}}, {_fmt(max(start, anchor - .34))});"
        )
    elif cue.graphic_type == "process":
        step_count = max(1, len(list(cue.content.get("steps") or [])[:3]))
        total = 0.28 + 0.07 * (step_count - 1)
        lines.append(
            f"tl.fromTo({selector} + ' .process-step', {{opacity:0, y:18}}, "
            f"{{opacity:1, y:0, duration:.28, stagger:.07, ease:'power3.out'}}, {_fmt(max(start, anchor - total))});"
        )
    elif cue.graphic_type == "concept_diagram":
        lines.extend([
            f"tl.fromTo({selector} + ' .diagram path', {{strokeDasharray:700, strokeDashoffset:700}}, {{strokeDashoffset:0, duration:.48, ease:'power2.inOut'}}, {_fmt(max(start, anchor - .48))});",
            f"tl.fromTo({selector} + ' .diagram-node', {{opacity:0, scale:.94}}, {{opacity:1, scale:1, duration:.28, stagger:.06, ease:'power3.out'}}, {_fmt(max(start, anchor - .40))});",
        ])
    elif cue.graphic_type == "asset_focus":
        lines.append(
            f"tl.fromTo({selector} + ' .asset-copy', {{opacity:0, y:18}}, "
            f"{{opacity:1, y:0, duration:.34, ease:'power3.out'}}, {_fmt(max(start, anchor - .34))});"
        )
    elif cue.graphic_type == "quote":
        lines.append(
            f"tl.fromTo({selector} + ' blockquote', {{opacity:0, y:18}}, {{opacity:1, y:0, duration:.36, ease:'power3.out'}}, {_fmt(max(start, anchor - .36))});"
        )
    else:
        lines.append(
            f"tl.fromTo({selector} + ' .keyword-rule i', {{scaleX:0}}, {{scaleX:1, duration:.34, ease:'power2.inOut'}}, {_fmt(max(start, anchor - .34))});"
        )
    lines.extend([
        f"tl.to({selector} + ' .graphic-shell', {{opacity:0, y:-10, duration:{_fmt(exit_duration)}, ease:'power2.in'}}, {_fmt(exit_at)});",
        f"tl.set({selector} + ' .graphic-shell', {{opacity:0}}, {_fmt(end)});",
    ])
    return "\n      ".join(lines)


def _source_media_markup(plan: GraphicsPlan, source_ref: str) -> str:
    """Emit framework-owned A-roll, audio, and fixed speaker windows.

    All media nodes are direct root children.  Speaker windows use authored
    fixed geometry plus opacity/scale motion, avoiding left/top/width/height
    tweens and the reflow/jank they caused in the previous wrapped-video path.
    """
    duration = float(plan.composition["durationSeconds"])
    ref = _escape(source_ref.replace("\\", "/"))
    parts = [f"""
      <video id="source-video" class="source-video" src="{ref}" muted playsinline preload="auto"
        data-start="0" data-duration="{_fmt(duration)}" data-track-index="0"></video>
      <audio id="source-audio" src="{ref}" preload="auto"
        data-start="0" data-duration="{_fmt(duration)}" data-track-index="10" data-volume="1"></audio>"""]
    for cue in plan.cues:
        if not cue.speaker_bounds:
            continue
        bounds = cue.speaker_bounds
        radius = "50%" if cue.speaker_shape == "circle" else "28px"
        parts.append(f"""
      <video id="speaker-{_escape(cue.id)}" class="speaker-media" src="{ref}" muted playsinline preload="auto"
        data-start="{_fmt(cue.start_sec)}" data-duration="{_fmt(cue.duration)}"
        data-media-start="{_fmt(cue.start_sec)}" data-track-index="2"
        data-crop-verification="{_escape('verified' if cue.speaker_crop_status == 'verified' else 'unverified')}"
        style="left:{bounds.x}px;top:{bounds.y}px;width:{bounds.width}px;height:{bounds.height}px;border-radius:{radius};"></video>""")
    return "\n".join(parts)


def _asset_video_markup(plan: GraphicsPlan, asset_refs: Mapping[str, str]) -> str:
    parts: list[str] = []
    for cue in plan.cues:
        asset_ref = asset_refs.get(cue.id)
        if not _is_video_ref(asset_ref):
            continue
        bounds = cue.graphic_bounds
        ref = _escape(str(asset_ref).replace("\\", "/"))
        parts.append(f"""
      <video id="asset-video-{_escape(cue.id)}" class="asset-host-video" src="{ref}" muted playsinline preload="auto"
        data-start="{_fmt(cue.start_sec)}" data-duration="{_fmt(cue.duration)}"
        data-media-start="0" data-track-index="4"
        style="left:{bounds.x}px;top:{bounds.y}px;width:{bounds.width}px;height:{bounds.height}px;"></video>""")
    return "\n".join(parts)


def _managed_media_timeline(plan: GraphicsPlan, asset_refs: Mapping[str, str],
                            include_source: bool = False) -> str:
    lines: list[str] = []
    for cue in plan.cues:
        lead = max(0.06, min(0.28, cue.anchor_sec - cue.start_sec))
        if include_source and cue.speaker_bounds:
            selector = json.dumps(f"#speaker-{cue.id}")
            lines.append(
                f"tl.fromTo({selector}, {{opacity:0, scale:.975}}, "
                f"{{opacity:1, scale:1, duration:{_fmt(lead)}, ease:'power3.out'}}, {_fmt(cue.start_sec)});"
            )
        if _is_video_ref(asset_refs.get(cue.id)):
            selector = json.dumps(f"#asset-video-{cue.id}")
            lines.append(
                f"tl.fromTo({selector}, {{opacity:0, scale:1.025}}, "
                f"{{opacity:1, scale:1, duration:{_fmt(lead)}, ease:'power3.out'}}, {_fmt(cue.start_sec)});"
            )
    return "\n      ".join(lines)


def build_composition(plan: GraphicsPlan, *, source_ref: str | None = None,
                      asset_refs: Mapping[str, str] | None = None) -> str:
    """Compile a validated graphics plan into one seek-safe HyperFrames page."""
    assert_plan_valid(plan)
    asset_refs = dict(asset_refs or {})
    composition = plan.composition
    width = int(composition["width"])
    height = int(composition["height"])
    duration = float(composition["durationSeconds"])
    fps = int(composition["fps"])
    cards = "\n".join(_card_markup(cue, asset_refs.get(cue.id)) for cue in plan.cues)
    card_timeline = "\n      ".join(_card_timeline(cue) for cue in plan.cues)
    media_markup = _asset_video_markup(plan, asset_refs)
    if source_ref:
        media_markup = "\n".join(filter(None, [_source_media_markup(plan, source_ref), media_markup]))
    media_timeline = _managed_media_timeline(plan, asset_refs, include_source=bool(source_ref))

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width={width},height={height}" />
  <style>
    @font-face {{ font-family:'Inter'; src:url('fonts/Inter-400-latin.woff2') format('woff2'); font-weight:400; font-display:block; }}
    @font-face {{ font-family:'Inter'; src:url('fonts/Inter-700-latin.woff2') format('woff2'); font-weight:700; font-display:block; }}
    :root {{ {_theme_css(plan.theme)} }}
    * {{ box-sizing:border-box; }}
    html,body {{ margin:0; width:{width}px; height:{height}px; overflow:hidden; background:var(--bg); font-family:'Inter',Arial,sans-serif; }}
    #stage {{ position:relative; width:100%; height:100%; overflow:hidden; isolation:isolate; background:var(--bg); color:var(--text); }}
    .source-video {{ position:absolute; inset:0; display:block; width:{width}px; height:{height}px; object-fit:cover; object-position:50% 36%; z-index:0; }}
    .speaker-media,.asset-host-video {{ position:absolute; display:block; object-fit:cover; object-position:50% 36%; overflow:hidden; transform-origin:center; will-change:transform,opacity; }}
    .speaker-media {{ z-index:2; box-shadow:0 18px 55px rgba(0,0,0,.32); }}
    .asset-host-video {{ z-index:2; border-radius:32px; }}
    .graphic-card {{ position:absolute; z-index:3; pointer-events:none; container-type:inline-size; }}
    .graphic-shell {{ position:relative; width:100%; height:100%; overflow:hidden; padding:clamp(24px,5cqi,64px); color:var(--text); border:1px solid color-mix(in srgb,var(--text) 13%,transparent); border-radius:clamp(20px,3.4cqi,42px); background:linear-gradient(145deg,color-mix(in srgb,var(--surface) 94%,transparent),color-mix(in srgb,var(--bg) 88%,transparent)); box-shadow:0 22px 80px rgba(0,0,0,.22); }}
    .layout-overlay .graphic-shell {{ background:linear-gradient(120deg,color-mix(in srgb,var(--bg) 82%,transparent),color-mix(in srgb,var(--surface) 62%,transparent)); backdrop-filter:blur(18px); }}
    .kicker {{ display:flex; align-items:center; gap:12px; color:var(--muted); font-size:clamp(14px,2.1cqi,22px); line-height:1; font-weight:700; letter-spacing:.14em; text-transform:uppercase; }}
    .kicker span {{ display:block; width:28px; height:3px; border-radius:3px; background:var(--cue-accent); }}
    h2 {{ margin:24px 0 0; max-width:15ch; font-size:clamp(46px,8.5cqi,116px); line-height:.95; letter-spacing:-.045em; text-wrap:balance; }}
    .stat-value {{ margin-top:clamp(28px,8cqi,78px); font-size:clamp(92px,24cqi,290px); line-height:.78; font-weight:700; letter-spacing:-.075em; color:var(--cue-accent); font-variant-numeric:tabular-nums; }}
    .stat-label {{ margin-top:clamp(24px,4cqi,48px); max-width:28ch; color:var(--text); font-size:clamp(24px,4.2cqi,48px); line-height:1.14; }}
    .measure {{ position:absolute; left:clamp(24px,5cqi,64px); right:clamp(24px,5cqi,64px); bottom:clamp(24px,5cqi,64px); height:5px; background:color-mix(in srgb,var(--text) 12%,transparent); }}
    .measure i {{ display:block; width:100%; height:100%; transform:scaleX(var(--measure-proportion)); transform-origin:left; background:var(--cue-accent); }}
    .comparison-grid {{ display:grid; grid-template-columns:1fr 44px 1fr; align-items:stretch; gap:20px; height:calc(100% - 54px); padding-top:clamp(28px,5cqi,58px); }}
    .comparison-side {{ display:flex; flex-direction:column; justify-content:space-between; padding:clamp(22px,4cqi,48px); border-radius:26px; background:color-mix(in srgb,var(--text) 6%,transparent); border:1px solid color-mix(in srgb,var(--text) 12%,transparent); }}
    .comparison-side small {{ color:var(--muted); font-size:18px; letter-spacing:.12em; }}
    .comparison-side strong {{ max-width:10ch; font-size:clamp(32px,6.2cqi,78px); line-height:.96; letter-spacing:-.04em; }}
    .comparison-side.is-accent {{ background:color-mix(in srgb,var(--cue-accent) 16%,var(--surface)); border-color:color-mix(in srgb,var(--cue-accent) 44%,transparent); }}
    .comparison-axis {{ position:relative; display:flex; align-items:center; justify-content:center; color:var(--cue-accent); }}
    .comparison-axis i {{ position:absolute; width:1px; height:100%; transform-origin:top; background:color-mix(in srgb,var(--text) 18%,transparent); }}
    .comparison-axis b {{ position:relative; padding:8px; background:var(--surface); font-size:24px; }}
    .process-line {{ position:relative; display:grid; gap:14px; margin-top:clamp(26px,5cqi,60px); }}
    .process-line::before {{ content:''; position:absolute; left:26px; top:26px; bottom:26px; width:2px; background:color-mix(in srgb,var(--cue-accent) 48%,transparent); }}
    .process-step {{ position:relative; display:grid; grid-template-columns:54px 1fr; align-items:center; gap:18px; min-height:78px; padding:12px 18px 12px 0; border-bottom:1px solid color-mix(in srgb,var(--text) 10%,transparent); font-size:clamp(24px,4cqi,46px); line-height:1.06; }}
    .process-step b {{ position:relative; display:grid; place-items:center; width:54px; height:54px; border-radius:50%; color:var(--bg); background:var(--cue-accent); font-size:15px; }}
    .diagram {{ position:relative; height:70%; min-height:280px; margin-top:10px; }}
    .diagram svg {{ position:absolute; inset:0; width:100%; height:100%; overflow:visible; }}
    .diagram path {{ fill:none; stroke:color-mix(in srgb,var(--cue-accent) 62%,var(--text)); stroke-width:3; vector-effect:non-scaling-stroke; }}
    .diagram-center,.diagram-node {{ position:absolute; display:grid; place-items:center; text-align:center; border-radius:999px; background:var(--surface); border:1px solid color-mix(in srgb,var(--text) 18%,transparent); text-transform:uppercase; letter-spacing:.08em; }}
    .diagram-center {{ left:50%; top:50%; width:160px; height:160px; transform:translate(-50%,-50%); color:var(--bg); background:var(--cue-accent); font-size:22px; font-weight:700; }}
    .diagram-node {{ width:132px; height:70px; padding:10px; color:var(--text); font-size:15px; }}
    .node-1 {{ left:3%; top:7%; }} .node-2 {{ right:2%; top:8%; }} .node-3 {{ right:8%; bottom:4%; }}
    .diagram-title {{ position:absolute; left:clamp(24px,5cqi,64px); right:clamp(24px,5cqi,64px); bottom:clamp(24px,4cqi,48px); margin:0; max-width:14ch; font-size:clamp(30px,5.2cqi,58px); }}
    .quote-mark {{ color:var(--cue-accent); font-family:Georgia,serif; font-size:clamp(100px,20cqi,240px); line-height:.66; }}
    blockquote {{ margin:clamp(28px,6cqi,72px) 0 0; max-width:18ch; font-size:clamp(44px,8.2cqi,112px); font-weight:700; line-height:.98; letter-spacing:-.045em; text-wrap:balance; }}
    .quote-rule {{ position:absolute; left:clamp(24px,5cqi,64px); bottom:clamp(24px,5cqi,64px); width:30%; height:5px; background:var(--cue-accent); }}
    .asset-frame {{ position:absolute; inset:0; overflow:hidden; }}
    .asset-media {{ width:100%; height:100%; object-fit:cover; }}
    .type-asset_focus.has-host-video .graphic-shell {{ background:transparent; }}
    .asset-shade {{ position:absolute; inset:0; background:linear-gradient(180deg,rgba(0,0,0,.22),rgba(0,0,0,.90)); }}
    .asset-copy {{ position:absolute; left:clamp(24px,5cqi,64px); right:clamp(24px,5cqi,64px); bottom:clamp(24px,5cqi,64px); }}
    .asset-copy .kicker {{ color:#fff; text-shadow:0 2px 14px rgba(0,0,0,.65); }}
    .asset-copy h2 {{ color:#fff; text-shadow:0 4px 24px rgba(0,0,0,.35); }}
    .keyword-title {{ margin-top:clamp(32px,8cqi,82px); max-width:12ch; }}
    .keyword-rule {{ margin-top:clamp(26px,5cqi,58px); width:min(460px,80%); height:6px; background:color-mix(in srgb,var(--text) 10%,transparent); }}
    .keyword-rule i {{ display:block; width:56%; height:100%; transform-origin:left; background:var(--cue-accent); }}
    .meaning-chip {{ position:absolute; right:clamp(24px,5cqi,64px); bottom:clamp(24px,5cqi,64px); padding:12px 18px; border-radius:999px; color:var(--bg); background:var(--cue-accent); font-size:clamp(16px,2.4cqi,24px); font-weight:700; text-transform:uppercase; letter-spacing:.08em; }}
  </style>
</head>
<body>
  <main id="stage" data-composition-id="graphics-main" data-start="0" data-duration="{_fmt(duration)}"
    data-fps="{fps}" data-width="{width}" data-height="{height}">{media_markup}
{cards}
  </main>
  <script src="vendor/gsap.min.js"></script>
  <script>
    (function() {{
      const tl = gsap.timeline({{paused:true}});
      {media_timeline}
      {card_timeline}
      tl.set('.graphic-card .graphic-shell', {{opacity:0}}, {_fmt(duration)});
      window.__timelines = window.__timelines || {{}};
      window.__timelines['graphics-main'] = tl;
    }})();
  </script>
</body>
</html>
"""


def write_composition(page_html: str, project_dir: str | Path) -> Path:
    """Write an HTML composition and stage local deterministic runtime assets."""
    project_path = Path(project_dir)
    project_path.mkdir(parents=True, exist_ok=True)
    _stage_runtime(project_path)
    index = project_path / "index.html"
    index.write_text(page_html, encoding="utf-8")
    return index


def _prepare_source_video(source: Path, destination: Path, fps: int,
                          duration: float) -> None:
    """Create a renderer-safe source with one-second GOPs and stable metadata."""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise FileNotFoundError("ffmpeg is required to prepare a seek-safe source video")
    destination.parent.mkdir(parents=True, exist_ok=True)
    command = [
        ffmpeg, "-y", "-i", str(source), "-t", _fmt(duration),
        "-map", "0:v:0", "-map", "0:a?", "-c:v", "libx264", "-preset", "medium",
        "-crf", "18", "-g", str(fps), "-keyint_min", str(fps), "-sc_threshold", "0",
        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
        "-map_metadata", "-1", "-movflags", "+faststart", str(destination),
    ]
    result = subprocess.run(
        command, capture_output=True, text=True, encoding="utf-8", errors="replace"
    )
    if result.returncode != 0:
        raise RuntimeError(f"source-video preparation failed:\n{result.stdout}\n{result.stderr}")


def _prepare_asset_video(source: Path, destination: Path, fps: int,
                         duration: float) -> None:
    """Normalize a selected motion asset to a browser-safe, seekable MP4."""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise FileNotFoundError("ffmpeg is required to prepare selected video assets")
    destination.parent.mkdir(parents=True, exist_ok=True)
    command = [
        ffmpeg, "-y", "-stream_loop", "-1", "-i", str(source), "-t", _fmt(duration),
        "-map", "0:v:0", "-an", "-c:v", "libx264", "-preset", "medium", "-crf", "18",
        "-g", str(fps), "-keyint_min", str(fps), "-sc_threshold", "0",
        "-pix_fmt", "yuv420p", "-map_metadata", "-1", "-movflags", "+faststart",
        str(destination),
    ]
    result = subprocess.run(
        command, capture_output=True, text=True, encoding="utf-8", errors="replace"
    )
    if result.returncode != 0:
        raise RuntimeError(f"asset-video preparation failed:\n{result.stdout}\n{result.stderr}")


def write_project(plan: GraphicsPlan, project_dir: str | Path,
                  source_video: str | Path | None = None,
                  prepare_source: bool = True) -> dict[str, Path]:
    """Stage media/assets, compile HTML, and persist a stable plan + QA report."""
    assert_plan_valid(plan)
    project_path = Path(project_dir)
    project_path.mkdir(parents=True, exist_ok=True)
    source = Path(source_video or plan.source_video).resolve() if (source_video or plan.source_video) else None
    source_ref: str | None = None
    if source:
        if not source.exists():
            raise FileNotFoundError(f"source video not found: {source}")
        media_dir = project_path / "media"
        media_dir.mkdir(parents=True, exist_ok=True)
        if prepare_source:
            destination = media_dir / "source-video.mp4"
            _prepare_source_video(
                source, destination, int(plan.composition["fps"]),
                float(plan.composition["durationSeconds"]),
            )
        else:
            destination = media_dir / f"source-video{source.suffix.lower()}"
            shutil.copy2(source, destination)
        source_ref = destination.relative_to(project_path).as_posix()

    asset_refs: dict[str, str] = {}
    asset_dir = project_path / "assets"
    for cue in plan.cues:
        if not cue.asset_path:
            continue
        source_asset = Path(cue.asset_path)
        asset_dir.mkdir(parents=True, exist_ok=True)
        if source_asset.suffix.lower() in {".mp4", ".mov", ".mkv", ".webm", ".m4v"}:
            destination = asset_dir / f"{cue.id}.mp4"
            _prepare_asset_video(
                source_asset, destination, int(plan.composition["fps"]), cue.duration
            )
        else:
            destination = asset_dir / f"{cue.id}{source_asset.suffix.lower()}"
            shutil.copy2(source_asset, destination)
        asset_refs[cue.id] = destination.relative_to(project_path).as_posix()

    page = build_composition(plan, source_ref=source_ref, asset_refs=asset_refs)
    index_path = write_composition(page, project_path)
    plan_path = project_path / "graphics-plan.json"
    plan_data = plan.to_dict()
    qa_issues = list(plan.qa)
    if source:
        plan_data["sourceVideo"] = str(source)
        if any(cue.speaker_bounds for cue in plan.cues):
            plan_data["composition"]["speakerCropVerification"] = {
                "status": "unverified",
                "method": "visual-review-required",
                "note": "No face/subject tracking is inferred from transcript timing alone.",
            }
            serialized_cues = {cue["id"]: cue for cue in plan_data["cues"]}
            existing = {(item.get("code"), item.get("cueId")) for item in qa_issues}
            for cue in plan.cues:
                if not cue.speaker_bounds:
                    continue
                serialized_cues[cue.id]["speaker_crop_status"] = "unverified"
                key = ("speaker_crop_unverified", cue.id)
                if key not in existing:
                    qa_issues.append({
                        "severity": "warning",
                        "code": "speaker_crop_unverified",
                        "cueId": cue.id,
                        "message": "speaker window is geometry-only; confirm face/subject framing in the visual export review",
                    })
    plan_data["qa"] = qa_issues
    plan_path.write_text(json.dumps(plan_data, indent=2, sort_keys=True), encoding="utf-8")
    qa_path = project_path / "graphics-qa.json"
    automated_passed = not any(i["severity"] == "error" for i in qa_issues)
    qa_report = {
        "automatedChecksPassed": automated_passed,
        "readiness": {
            "readyForDelivery": False,
            "status": "review-required" if automated_passed else "automated-checks-failed",
            "requiredReviews": [
                {
                    "id": "visual-composition-review",
                    "status": "pending",
                    "checks": ["speaker crop", "caption clearance", "trigger-frame legibility", "asset framing"],
                },
                {
                    "id": "export-playback-review",
                    "status": "pending",
                    "checks": ["decoded media motion", "audio sync", "first/last frame", "mobile platform UI overlay"],
                },
            ],
        },
        "issues": qa_issues,
    }
    qa_path.write_text(json.dumps(qa_report, indent=2, sort_keys=True), encoding="utf-8")
    return {"index": index_path, "plan": plan_path, "qa": qa_path}


def title_card(title: str, subtitle: str | None = None, duration: float = 3.0,
               accent: str = "#22d3ee", width: int = 1080, height: int = 1920,
               title_size: int = 72, sub_size: int = 36) -> str:
    """Legacy single-card generator, upgraded to local runtime and fluid motion."""
    title_text = _escape(title)
    subtitle_markup = f'<p id="subtitle">{_escape(subtitle)}</p>' if subtitle else ""
    subtitle_timeline = (
        "tl.fromTo('#subtitle',{opacity:0,y:14},{opacity:1,y:0,duration:.46,ease:'power3.out'},.28);"
        if subtitle else ""
    )
    subtitle_kill = "tl.set('#subtitle',{opacity:0},D);" if subtitle else ""
    safe_accent = _css(accent)
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8" />
<style>
@font-face{{font-family:'Inter';src:url('fonts/Inter-400-latin.woff2') format('woff2');font-weight:400}}
@font-face{{font-family:'Inter';src:url('fonts/Inter-700-latin.woff2') format('woff2');font-weight:700}}
*{{box-sizing:border-box}}html,body{{margin:0;width:{width}px;height:{height}px;overflow:hidden;background:#0B1118;font-family:'Inter',Arial,sans-serif}}
#root{{position:relative;width:100%;height:100%;display:grid;place-items:center;color:#F7FAFC;overflow:hidden}}
#content{{position:relative;width:82%;padding:70px 64px;border:1px solid rgba(255,255,255,.12);border-radius:38px;background:linear-gradient(145deg,#13212D,#0E171F);box-shadow:0 30px 100px rgba(0,0,0,.28)}}
#rule{{width:76px;height:6px;border-radius:6px;background:{safe_accent};transform-origin:left}}
h1{{margin:28px 0 0;font-size:{title_size}px;line-height:.94;letter-spacing:-.045em;text-wrap:balance}}
p{{margin:22px 0 0;color:{safe_accent};font-size:{sub_size}px;line-height:1.12;font-weight:700}}
</style></head><body>
<main id="root" data-composition-id="main" data-start="0" data-duration="{_fmt(duration)}" data-width="{width}" data-height="{height}">
<section id="content" class="clip" data-start="0" data-duration="{_fmt(duration)}" data-track-index="1"><div id="rule"></div><h1 id="title">{title_text}</h1>{subtitle_markup}</section>
</main><script src="vendor/gsap.min.js"></script><script>
window.__timelines=window.__timelines||{{}};const D={_fmt(duration)};const tl=gsap.timeline({{paused:true}});
tl.fromTo('#content',{{opacity:0,y:24,clipPath:'inset(0 0 10% 0)'}},{{opacity:1,y:0,clipPath:'inset(0 0 0% 0)',duration:.58,ease:'power3.out'}},0);
tl.fromTo('#rule',{{scaleX:0}},{{scaleX:1,duration:.52,ease:'power2.inOut'}},.10);
tl.fromTo('#title',{{opacity:0,y:18}},{{opacity:1,y:0,duration:.5,ease:'power3.out'}},.18);{subtitle_timeline}
tl.to('#content',{{opacity:0,y:-10,duration:.28,ease:'power2.in'}},Math.max(.6,D-.28));tl.set('#title',{{opacity:0}},D);{subtitle_kill}
window.__timelines['main']=tl;</script></body></html>"""


def _npx(args: list[str], cwd: str | Path, env: Mapping[str, str] | None = None,
         timeout: int = 600) -> subprocess.CompletedProcess[str]:
    executable = shutil.which("npx") or shutil.which("npx.cmd") or "npx"
    return subprocess.run(
        [executable, *args], cwd=str(cwd), capture_output=True, text=True,
        encoding="utf-8", errors="replace", env=dict(env) if env else None,
        timeout=timeout, shell=False,
    )


def lint(project_dir: str | Path) -> str:
    result = _npx(["hyperframes", "lint"], cwd=project_dir)
    if result.returncode != 0:
        raise RuntimeError(f"hyperframes lint failed:\n{result.stdout}\n{result.stderr}")
    return result.stdout


def render(project_dir: str | Path, out_path: str | Path, fps: int = 30,
           quality: str = "draft", output_format: str = "mp4") -> str:
    """Render through HyperFrames with the verified local Chromium fallback."""
    env = os.environ.copy()
    shell_path = (r"C:\Users\Iniolu\AppData\Local\ms-playwright\chromium_headless_shell-1228"
                  r"\chrome-headless-shell-win64\chrome-headless-shell.exe")
    if Path(shell_path).exists():
        env.setdefault("PRODUCER_HEADLESS_SHELL_PATH", shell_path)
    env.setdefault("HYPERFRAMES_SKIP_SKILLS", "1")
    result = _npx(
        ["hyperframes", "render", "-o", str(Path(out_path).resolve()), "-f", str(fps),
         "-q", quality, "--format", output_format, "--no-browser-gpu"],
        cwd=project_dir, env=env,
    )
    if result.returncode != 0:
        raise RuntimeError(f"hyperframes render failed:\n{result.stdout}\n{result.stderr}")
    return result.stdout


def _load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Semantic graphics planner + HyperFrames compositor")
    parser.add_argument("--transcript", help="word-timed JSON; enables semantic multi-cue planning")
    parser.add_argument("--title", help="legacy one-card mode")
    parser.add_argument("--subtitle")
    parser.add_argument("--duration", type=float)
    parser.add_argument("--accent", default="#22d3ee")
    parser.add_argument("--platform", default="reels", choices=["reels", "tiktok", "shorts", "youtube", "x"])
    parser.add_argument("--niche", default="general")
    parser.add_argument("--goal", default="retention and clarity")
    parser.add_argument("--source-video")
    parser.add_argument("--assets-dir", action="append", default=[])
    parser.add_argument("--allow-meme-assets", action="store_true")
    parser.add_argument("--no-captions", action="store_true", help="do not reserve the caption safe region")
    parser.add_argument("--fps", type=int)
    parser.add_argument("--width", type=int)
    parser.add_argument("--height", type=int)
    parser.add_argument("--project-dir", required=True)
    parser.add_argument("--lint-only", action="store_true")
    parser.add_argument("--skip-lint", action="store_true")
    parser.add_argument("--render", help="output path; omit to only build the project")
    parser.add_argument("--quality", default="draft", choices=["draft", "standard", "high"])
    args = parser.parse_args(argv)

    if args.transcript:
        transcript = _load_json(args.transcript)
        plan = plan_graphics(
            transcript, duration=args.duration, platform=args.platform, niche=args.niche,
            goal=args.goal, source_video=args.source_video, asset_dirs=args.assets_dir,
            captions_enabled=not args.no_captions, allow_meme_assets=args.allow_meme_assets,
            fps=args.fps, width=args.width, height=args.height,
        )
        paths = write_project(plan, args.project_dir, source_video=args.source_video)
        print(f"planned {len(plan.cues)} purposeful graphics")
        for cue in plan.cues:
            print(f"  {cue.start_sec:7.3f}s  {cue.graphic_type:16s}  {cue.layout:11s}  anchor={cue.anchor_word!r}")
        print(f"plan: {paths['plan']}")
        print(f"qa:   {paths['qa']}")
        print(f"html: {paths['index']}")
    else:
        if not args.title:
            parser.error("provide --transcript for semantic mode or --title for legacy card mode")
        duration = args.duration if args.duration is not None else 3.0
        page = title_card(args.title, subtitle=args.subtitle, duration=duration,
                          accent=args.accent, width=args.width or 1080, height=args.height or 1920)
        paths = {"index": write_composition(page, args.project_dir)}
        print(f"html: {paths['index']}")

    if not args.skip_lint:
        print(lint(args.project_dir))
    if args.render and not args.lint_only:
        fps = args.fps or 30
        print(render(args.project_dir, args.render, fps=fps, quality=args.quality))
        print(f"rendered: {Path(args.render).resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
