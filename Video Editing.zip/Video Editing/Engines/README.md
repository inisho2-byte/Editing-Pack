---
title: "Video Editing OS Engines"
category: architecture
last_updated: 2026-07-12
tags: [video-editing, captions, motion-graphics, edl, hyperframes]
---

# Video Editing OS Engines

The engine layer turns forced-aligned source speech into a reviewed edit, then
drives captions and graphics from one post-cut clock. It is designed for the
finished short-form language demonstrated inside `Assets/Video example/`: tight
speech, meaning-led visual changes, speaker/graphic layout variety, sparse word
emphasis, and fluid motion without template effects.

## Engine Map

| Engine | Owns | Does not own |
|---|---|---|
| [[Captions_engine/README|Captions Engine]] | Forced alignment, semantic phrasing, platform style, ASS/HyperFrames output, caption QA | Editorial deletion or graphics |
| [[Graphics_engine/README|Graphics Engine]] | Information-shape selection, exact trigger-word anchors, assets, layout/PiP choreography, HyperFrames composition, graphics QA | Speech cleanup, captions, footage grade |
| [[Video editing engine/README|Video Editing Engine]] | Cleanup decisions, reviewed EDL, word-safe cuts, retiming, HDR/audio/render order, combined export QA | Silently deciding taste or low-confidence semantic deletions |

## One-Clock Contract

```text
forced-aligned source words
  -> editorial plan + human-reviewed EDL
  -> timeline_map + retimed_words (output seconds)
       -> captions from retimed_words
       -> graphics from the same retimed_words
  -> graphics first -> captions last -> export QA
```

After cleanup, `approved_edl.editorial.retimed_words` is the timing source of
truth. Generating final captions or graphics from the original transcript will
reintroduce drift and is prohibited.

The render path keeps per-cut audio as PCM and encodes AAC only once after
assembly. This avoids encoder priming accumulating at each cut. EDL validation
also reconstructs every retimed word from source words and selected ranges, so
a stale or modified timing handoff fails before render.

## Recommended Workflow

1. Produce WhisperX-forced word timestamps or another forced-aligned word JSON.
2. Plan only; do not render yet:

```powershell
cd "Editing_OS/Video Editing/Engines/Video editing engine"
python engine.py --input raw.mp4 --plan-edits --words-json words.json `
  --platform reels --pacing adaptive --cleanup-strength balanced
```

3. Review `editorial-plan.json` and `edl.json`. Confirm automatic cleanup,
   every `review_required` decision, the hook candidates, and intentional pauses.
4. Apply the approved EDL, optionally running the graphics engine in the same
   output-timeline pass:

```powershell
python engine.py --apply-edits --edl-in .raw_edit_plan/edl.json `
  --graphics --graphics-niche tech --graphics-assets-dir C:\edit\assets `
  --graphics-quality standard --out final.mp4
```

The integrated path does not run ASR again. It renders the cleaned base, plans
graphics from the approved `retimed_words`, renders the packaged HyperFrames
composition, then phrases and burns captions from that same word list last.

## Editorial Safety

Automatic deletions are limited to high-confidence mechanics: excessive dead
air, non-lexical filler, clear stutters/false starts, and adjacent near-verbatim
retakes. Semantic similarity is review-only. Explicit `[beat]`, `[pause]`,
ellipsis, laughter, applause, and pause-preservation metadata protect comedic or
emotional timing.

All cut edges are checked against word intervals. Padding must stay within the
verified 30–200 ms window unless adjacent speech constrains it, in which case QA
records a warning.

## Visual Language

- Refresh the visual experience on a meaningful beat, normally every 2–4 seconds
  in short form; never refresh solely because a timer elapsed.
- Use one focal graphic: stat, comparison, process, concept diagram, quote,
  real matching asset, or meaning-word treatment.
- Rotate speaker-full, split-stage, circular PiP, and full-stage states when the
  idea earns the change.
- Reserve platform UI and caption regions. Do not cover faces, products, proof,
  or critical screen content.
- Use continuous eased motion. Reject spin/zoom presets, glitch filler, constant
  bounce, mechanical drift, and whoosh-on-every-cut behavior.
- Meme assets are opt-in. A filename/tag match and niche fit are required before
  any local asset is selected.

## Taste Options

Correctness decisions are fixed automatically; taste is not. Before a long
render, generate two or three real-material variants when choosing caption
accent/type, graphics niche/theme, music, or color. Keep the content/timing plan
constant so the human is choosing the look rather than comparing different edits.

## QA and Readiness

Each engine writes a machine-readable QA artifact. Automated checks cover word
timing, exposure, overlap, output mapping, layout/caption collisions, asset
validity, deterministic composition, HDR handling, and expected duration.

Automated success is not publication approval. Reports keep `ready: false` until
the actual export is watched and the manual checklist is completed: first and
last frames, every cut window, caption/face collisions, graphic timing, dialogue
clarity, motion fluidity, phone safe areas, and target-platform playback.

## Verification Commands

```powershell
cd "Editing_OS/Video Editing/Engines/Captions_engine"
python -B engine.py --selftest

cd "../Graphics_engine"
python -m unittest -v test_graphics_engine.py

cd "../Video editing engine"
python -m unittest -v test_editorial.py test_apply_integration.py
```

See [[Editing_OS/Skills/TOOL_ROUTING|Tool Routing]] and
[[Editing_OS/Skills/TASTE_PROFILE|Taste Profile]] for the governing orchestration and
aesthetic rules.
