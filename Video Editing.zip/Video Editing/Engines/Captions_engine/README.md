---
title: "Captions Engine"
category: engine
last_updated: 2026-07-12
tags: [video-editing, captions, forced-alignment, qa]
---

# Captions Engine — word-aligned semantic caption planning

The production caption seam for the Editing OS. It turns audio **or pre-aligned
words** into one deterministic caption plan and emits it for both render paths:

- `*.ass` — burnable, platform-safe ASS with exact word reveals and restrained
  meaning-word emphasis.
- `*.captions.json` — HyperFrames `hyperframes-captions/v1` data, revision 2.
- `*.qa.json` — a required static QA report. Render artifacts are blocked when
  correctness checks fail unless `--allow-qa-errors` is explicitly used.

The engine optimizes for the caption rules in the Editing OS: forced alignment,
one idea per caption, no mid-phrase splits, comfortable exposure, scarce
semantic emphasis, platform-native presentation, and deterministic output.

## What changed in the production upgrade

1. **Alignment is authoritative.** WhisperX phoneme alignment is required by
   the default `auto` backend; it never silently downgrades to raw Whisper.
   Upstream WhisperX words can be supplied directly with `--words-json` so the
   caption stage never re-transcribes or estimates timing.
2. **Corrected scripts are evidence-aware.** Exact ASR anchors stay exact;
   replacements and insertions are marked `script-replacement` or
   `script-interpolated`. Grossly unrelated scripts are refused. Approximate
   words are called out in QA instead of being presented as forced-aligned.
3. **Phrasing is semantic.** A dynamic-programming segmenter prefers sentence,
   clause, connector, and pause boundaries while protecting articles,
   prepositions, and tightly bound phrases. Rapid unreadable micro-captions are
   merged when a legal non-overlapping handoff is otherwise impossible.
4. **Timing includes reading behavior.** Spoken windows remain immutable;
   separate display windows add a hold where available, never overlap the next
   caption, and carry an estimated required reading duration.
5. **Emphasis has hierarchy.** Functional words are quiet. Numbers, negations,
   proper terms, and high-impact meaning words are scored; only one primary
   emphasis word is selected by default. No Tier-4 spectacle is assigned
   automatically.
6. **Styles adapt to the destination.** Reels, TikTok, Shorts, X, landscape
   YouTube, and a compatibility profile have different density, motion,
   typography scale, accent, and platform safe-area metadata.
7. **ASS follows absolute word onsets.** Every later word has an absolute
   millisecond reveal relative to its segment. Karaoke durations are measured
   onset-to-onset, so inter-word silence is preserved and cannot accumulate
   timing drift.
8. **QA is executable.** Timing monotonicity, overlap tolerance, word coverage,
   segment envelopes, minimum exposure, reading-time pressure, line limits,
   emphasis density, display handoffs, safe-area validity, and style contrast
   are checked before render.

## Files

| File | Responsibility |
|---|---|
| `engine.py` | CLI, deterministic input path, orchestration, atomic artifact writes. |
| `align.py` | WhisperX / Whisper backends, timing normalization, corrected-script remapping and provenance. |
| `phrasing.py` | Semantic segmentation, natural line wrapping, display windows, reading behavior, meaning-word scoring. |
| `emit.py` | Platform profiles, exact-onset ASS, HyperFrames revision-2 payload, stable fingerprint. |
| `validate.py` | Static production gate and explicit visual/device review contract. |
| `test_engine.py` | Pure-Python regression and integration tests; no models or audio required. |

## Recommended use

Use forced-aligned words from the upstream transcription stage when available:

```powershell
python engine.py `
  --words-json edit/transcript.words.json `
  --platform instagram-reels `
  --out-prefix edit/captions
```

Accepted word JSON shapes:

```json
[{"text":"Every", "start":0.12, "end":0.38, "score":0.98}]
```

```json
{"words":[...]}
```

```json
{"segments":[{"words":[...]}]}
```

Or transcribe audio inside this engine:

```powershell
# Auto means the production forced aligner. It fails if WhisperX is unavailable.
python engine.py --audio VO.wav --platform youtube-shorts --out-prefix edit/captions

# Require phoneme forced alignment. This fails if WhisperX is unavailable.
python engine.py --audio VO.wav --backend whisperx --model large-v3 `
  --platform instagram-reels --out-prefix edit/captions

# Diagnostic escape hatch only: explicit lower-confidence raw ASR timestamps.
python engine.py --audio VO.wav --backend whisper --out-prefix edit/captions
```

Correct names and terminology with a verified script:

```powershell
python engine.py --words-json edit/transcript.words.json `
  --script script.txt --platform x --out-prefix edit/captions
```

The corrected script changes caption text while borrowing real timing evidence.
Any non-exact mapping is visible in each word's `timing_source` and in QA. A
script that is not recognizably related to the transcript is rejected.

## Platform profiles

| `--platform` | Default reading surface | Design intent | Safe-area behavior |
|---|---|---|---|
| `instagram-reels` | 7 words / 2 lines | Designed, clean cyan emphasis; restrained scale settle | Extra right and bottom clearance for Reels UI |
| `tiktok` | 6 words / 2 lines | Raw/native, faster pop, yellow semantic accent | Largest right/bottom clearance |
| `youtube-shorts` | 8 words / 2 lines | Legible and clean; calmer motion | Shorts UI right/bottom clearance |
| `x` | 11 words / 2 lines | Dense, information-forward | Reduced side/bottom reservation |
| `youtube` | 12 words / 2 lines | Landscape clean subtitle system | Landscape-safe margins |
| `generic` | 8 words / 2 lines | Backward-compatible ARETE white/yellow treatment | Legacy-style margins |

List installed profiles:

```powershell
python engine.py --print-profiles
```

Profiles are starting systems, not universal taste decisions. Override only a
deliberate project-level choice and keep it consistent across the piece:

```powershell
python engine.py --words-json words.json --platform instagram-reels `
  --font Arial --font-size 56 --accent "#FFB000" --out-prefix captions
```

Font sizes are authored against a 1080-pixel short edge. Thus the authored
YouTube size remains intact at 1920×1080, portrait sizes remain intact at
1080×1920, and both orientations scale consistently at 720p or 4K.

## Semantic timing model

Each segment has two time domains:

- `speech_start` / `speech_end` — exact first/last aligned word evidence.
- `start` / `end` in HyperFrames — the non-overlapping display window.

Every word retains absolute `start` / `end` plus `rel_start` / `rel_end` for a
seek-safe renderer. The full phrase can occupy stable layout, while words are
revealed at their aligned onsets. This avoids both anticipation and the layout
jump caused by rebuilding a text block on every word.

ASS uses the same plan. If word onsets are `0 ms`, `420 ms`, and `1030 ms`, the
first two karaoke periods are `42 cs` and `61 cs`; the second and third words
also receive absolute reveal transforms at `420 ms` and `1030 ms`. Silence is
therefore part of the timing model rather than discarded.

## HyperFrames contract

The schema name remains `hyperframes-captions/v1` for existing consumers.
`schema_revision: 2` adds fields without removing the v1 fields:

```json
{
  "schema": "hyperframes-captions/v1",
  "schema_revision": 2,
  "platform": "instagram-reels",
  "source_fingerprint": "sha256...",
  "style_profile": {"safe_area": {}, "motion": "scale-settle"},
  "clips": [{
    "id": "caption-0001",
    "start": 0.12,
    "end": 1.48,
    "speech_start": 0.12,
    "speech_end": 1.31,
    "reading_behavior": "skimming",
    "required_read_duration": 1.25,
    "lines": [["This", "changes"], ["everything."]],
    "emphasis": [{"word_index": 2, "text": "everything.", "motion_tier": 2}],
    "words": [{
      "text": "This", "start": 0.12, "end": 0.34,
      "rel_start": 0.0, "rel_end": 0.22,
      "timing_source": "whisperx-forced",
      "role": "functional", "emphasis": false, "motion_tier": 1
    }]
  }]
}
```

The SHA-256 `source_fingerprint` depends only on the canonical words, config,
platform, and resolution. It is written into the HyperFrames JSON, QA JSON, and
ASS header so an orchestrator can prove that all three artifacts belong to the
same plan. Outputs contain no clock time, random value, or machine-dependent
path.

## QA gate

Strict QA is the default. If a plan contains errors, any older `.ass` and
`.captions.json` at the same prefix are removed before the new failing
`.qa.json` is published. A stale render artifact can therefore never sit beside
a report for a different, failing plan.

Automated errors include:

- invalid, non-monotonic, or >80 ms overlapping word timing;
- missing, duplicated, or reordered caption words;
- segment/display windows that fail to envelop their words;
- caption exposure below the platform minimum;
- overlapping caption display windows;
- line-count/line-width overflow;
- more primary emphasis words than allowed;
- invalid safe-area fractions or insufficient text-to-outline contrast.

Warnings include low-confidence / interpolated timing and speech that leaves
less than estimated reading time. Warnings require review but do not block
artifacts. `--allow-qa-errors` exists for diagnosis only; it is not a shipping
mode.

Static QA cannot see the footage. The report always includes the final visual
review contract:

1. Check contrast over bright, busy, and changing frames.
2. Check eyes, mouth, products, and critical graphics for collisions.
3. Overlay the current platform UI and verify on a phone.
4. Review approximate/low-confidence words at waveform level.
5. Watch normally and muted to verify hierarchy, comprehension, and restraint.

After timeline trims, dead-space cuts, reordered phrases, or speed changes,
regenerate word timings and captions. Never assume captions built for an older
cut remain synchronized.

## Focused tests

```powershell
python engine.py --selftest
```

The suite covers semantic boundaries, phrase glue, natural wrapping, pause and
duration breaks, micro-caption merging, handoffs, emphasis restraint,
corrected-script provenance/refusal (including the one-anchor failure case),
forced-alignment backend policy, platform-native scaling, safe ASS transcript
escaping, exact uneven-gap timing, deterministic HyperFrames output, stale-file
cleanup on QA failure, and atomic three-artifact integration. When FFmpeg with
libass is available, it also renders an escape smoke frame and proves a literal
`\\N` remains on one line.

## Dependencies and limitations

- `whisperx` is the production backend and supplies phoneme forced alignment.
  Install it in the runtime environment used by the OS, or supply already
  forced-aligned `--words-json`.
- `openai-whisper` is an explicit diagnostic escape hatch (`--backend whisper`),
  never an automatic fallback. Its timing source and QA warning clearly mark
  the result as lower-confidence.
- Corrected-script interpolation is not a replacement for phoneme alignment. It
  is labeled approximate and must be reviewed where QA flags it.
- The engine plans caption placement inside declared platform safe areas. Face,
  prop, burned-in-text, and background-luminance collision checks require actual
  frame analysis in the render/QA stage.

## Related pages

- [[Projects/Personal projects/AI Projects/Video editing tools/Editing_OS/Video Editing/Engines/README|Video Editing OS Engines]]
- [[Projects/Personal projects/AI Projects/Video editing tools/Editing_OS/Video Editing/Engines/Video editing engine/README|Video Editing Engine]]
- [[Projects/Personal projects/AI Projects/Video editing tools/Editing_OS/Video Editing/Engines/Graphics_engine/README|Graphics Engine]]
