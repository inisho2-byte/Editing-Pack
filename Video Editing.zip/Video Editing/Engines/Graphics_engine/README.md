---
title: "Graphics Engine"
category: engine
last_updated: 2026-07-12
tags: [video-editing, graphics, hyperframes, qa]
---

# Graphics Engine

Transcript-aware planning and deterministic HyperFrames composition for the
Video Editing OS. The engine selects **why**, **what**, **when**, and **where** a
graphic should appear before it renders anything.

It owns title cards, semantic callouts, statistics, comparisons, process flows,
concept diagrams, pull quotes, local-asset features, split layouts, and speaker
PiP/stage takeovers. Captions remain the `Captions_engine`'s responsibility;
footage cleanup, cuts, audio, and color remain the `Video editing engine`'s
responsibility.

## Reference target

The finished content inside `Assets/Video example/` was used as the target; the
outer before/after and social-app wrappers were ignored. The useful signals were:

- Alternate speaker-led and graphic-led states instead of leaving the speaker
  full-frame for the whole video.
- One semantic visual per idea: a bulb for an idea, a maze for a path/problem,
  a staged phone/data panel for a product, or large typography for a meaning word.
- Refresh on a meaningful spoken beat, normally every 2-4 seconds in short form,
  not on a blind timer.
- Let the speaker move to a left split or circular corner PiP when the explanation
  deserves a full graphic stage.
- Keep one dominant focal point. Dark or editorial-light stages, restrained color,
  strong hierarchy, and negative space read more premium than stacked effects.
- Use continuous eased motion. No spin transitions, hard bounce, glitch filler,
  mechanical drift, or template carousel behavior.

Those are encoded as planner and QA rules rather than left as prompt advice.

## Pipeline

```text
word-timed transcript
  -> clause phrasing at punctuation/pauses
  -> semantic value scoring
  -> exact trigger-word anchor
  -> purposeful graphic type
  -> platform/niche layout and theme
  -> local asset match (optional)
  -> safe-area, caption, collision, density, and timing QA
  -> stable graphics-plan.json
  -> offline HyperFrames index.html
```

`planner.py` owns analysis and QA. `compose.py` owns HTML compilation, media
staging, HyperFrames lint/render, and the legacy `title_card()` API.

## Graphic selection

Clauses have to earn a graphic. The planner scores these signals:

| Signal | Graphic | Why it earns screen time |
|---|---|---|
| Number, percentage, currency, multiplier | `stat` | Makes a specific claim immediately legible |
| Versus, before/after, instead, better/worse | `comparison` | Clarifies a real contrast |
| First/next/then, steps, test/build/measure | `process` | Shows sequence rather than repeating prose |
| Because/why/means/system/loop/distribution | `concept_diagram` | Makes a mechanism tangible |
| A genuine quotation/mantra | `quote` | Preserves a memorable line |
| Product, podcast, phone, app, screen plus a matching local file | `asset_focus` | Shows the real subject instead of a generic icon |
| Strong meaning word | `emphasis` / `keyword` | Gives one important word hierarchy |

Filler-heavy fragments, weak short clauses, and clauses below the platform's
information threshold receive no graphic. There is no forced minimum count.

## Timing contract

Input must contain forced-aligned word timestamps. Both `text` and `word` keys are
accepted, including WhisperX `segments[].words[]` and HyperFrames/Whisper flat
`words[]`.

```json
[
  {"text": "First", "start": 4.20, "end": 4.45},
  {"text": "test", "start": 4.48, "end": 4.72},
  {"text": "3", "start": 4.75, "end": 4.88},
  {"text": "ideas.", "start": 4.91, "end": 5.30}
]
```

For a stat, `anchor_sec` is the start of `3`, not an estimated fraction of the
sentence. The card shell now leads that instant and every cue-specific reveal is
scheduled to finish by the trigger frame; the number, comparison, process, or
diagram is therefore legible when the audience hears the motivating word, not
several frames afterward. All starts, anchors, ends, and animation statements
are quantized to the composition FPS. Cues are de-overlapped with a breathing
gap and kept short enough to preserve a 2-4 second short-form refresh ceiling.

Word intervals are strict input: overlapping intervals are rejected, as is any
word whose `end` exceeds the composition duration. A merely chronological start
list is not sufficient because it can still contain two simultaneously active
words and create ambiguous graphic anchors.

Stat bars are evidence-bound. A measure is drawn only for an explicit percentage,
fraction, unit-interval decimal, `N percent`, or `N out of M`, and its rendered
scale is the parsed value. A bare count such as `3 prototypes` still earns a
large number card but never fabricates a progress percentage.

## Layout system

| Layout | Speaker state | Use |
|---|---|---|
| `overlay` | Full-frame | Short emphasis or quote; graphic stays in the upper safe zone |
| `side_panel` | Left/upper rounded frame | Comparison or dense speaker + data moment |
| `stage_pip` | Circular top-corner PiP | Diagram, process, asset, or stat gets the main stage |
| `full_stage` | Dimmed behind the graphic | Peak stat/idea that needs one clean focal point |
| `lower_third` | Full-frame | Only available when captions are not reserving that region |

The planner prevents repeated layout ruts and provides explicit
`graphic_bounds`, `speaker_bounds`, and `speaker_shape` in the plan. Speaker
framing transitions use continuous `power3.inOut` interpolation. There is no
resting zoompan or mechanical pendulum drift.

## Platform and niche adaptation

Built-in platform profiles use the same normalized safe-area fractions as the
caption engine, then calculate pixels from the actual render width/height. This
keeps 2x and arbitrary custom resolutions geometrically equivalent:

| Platform | Top | Right | Bottom | Left |
|---|---:|---:|---:|---:|
| `reels` / Instagram Reels | 10% | 18% | 20% | 7% |
| `tiktok` | 11% | 19% | 23% | 7% |
| `shorts` / YouTube Shorts | 9% | 17% | 18% | 7% |
| `youtube` | 6% | 6% | 11% | 6% |
| `x` | 7% | 8% | 14% | 8% |

The caption reservation itself is also height-normalized and sits immediately
above the scaled bottom UI margin. `safeAreas.platformUI.fractions` records the
source fractions beside the computed pixel rectangles for auditability.

Built-in niche themes include `tech`, `finance`, `luxury`, `fitness`, `podcast`,
`education`, and `documentary`. They are intentionally restrained: saturation is
bounded and color is used as hierarchy, not decoration. Unknown niches fall back
to the clean adaptive-precision theme.

## Asset policy

`--assets-dir` recursively indexes local images and video by stable, sorted file
name/path tags. A file is selected only when its tags overlap the spoken subject.
Audio files are ignored. Directories named `Memes` are excluded unless
`--allow-meme-assets` is explicit; this prevents an entertainment asset from
appearing in finance, education, or documentary work by accident.

Selected images are copied into the render project with cue-stable names.
Selected video is normalized with FFmpeg to seekable H.264/yuv420p MP4 and
emitted as a direct, timed child of the composition root. It is never nested in
an asset frame, so HyperFrames owns decode, visibility, and seeking instead of
capturing a frozen or blank media panel. The generated page never references
the original absolute path.

## Offline and deterministic rendering

Generated pages have no live CDN, web font, or remote media dependency.
`write_project()` stages:

```text
vendor/gsap.min.js
fonts/Inter-400-latin.woff2
fonts/Inter-700-latin.woff2
media/source-video.<ext>       # when supplied
assets/graphic-XX.<ext>        # when selected
```

The local runtime/fonts come from the vendored HyperFrames
`talking-head-recut/assets/` directory. The page registers one paused master
timeline at `window.__timelines['graphics-main']`. It contains no network calls,
`Date.now()`, `Math.random()`, infinite repeats, timers, async timeline building,
or media `play()` calls. A-roll `<video>` is muted and direct-root; its sound is a
separate direct-root `<audio>` track. Speaker windows and selected motion assets
are also fixed-size direct-root media clips. Their motion uses only opacity and
transform scale, eliminating the earlier `left`/`top`/`width`/`height` layout
tweens that could reflow or jump during seek-driven capture.

By default, supplied footage is re-encoded to H.264 with a one-second GOP,
scene-cut keyframes disabled, stripped metadata, and AAC audio. This prevents
sparse-keyframe sources from freezing during non-linear frame seeks. Advanced
callers with an already prepared source may pass `prepare_source=False` to
`write_project()`.

## CLI

Semantic multi-graphic mode:

```powershell
python compose.py `
  --transcript C:\edit\words.json `
  --duration 42.8 `
  --source-video C:\edit\clean-cut.mp4 `
  --platform reels `
  --niche tech `
  --goal "explain the mechanism and hold retention" `
  --assets-dir C:\edit\assets `
  --project-dir C:\hf_render\graphics-01
```

This writes:

```text
graphics-01/
  index.html
  graphics-plan.json
  graphics-qa.json
  vendor/
  fonts/
  media/        # optional
  assets/       # optional
```

Add `--render C:\hf_render\graphics-01\output.mp4 --quality standard` for
a render. Lint runs by default. Use `--skip-lint` only in a controlled test.

Legacy title card mode remains compatible with the sibling editing engine:

```powershell
python compose.py --title "ARETE" --subtitle "Agentic OS" --duration 2.5 `
  --project-dir C:\hf_render\title-01
```

## Python API

```python
from planner import plan_graphics
from compose import write_project

plan = plan_graphics(
    transcript_words,
    duration=42.8,
    platform="reels",
    niche="podcast",
    goal="make the argument clear and memorable",
    source_video="clean-cut.mp4",
    asset_dirs=["assets"],
    captions_enabled=True,
)

paths = write_project(plan, "C:/hf_render/graphics-01")
```

The plan is deliberately inspectable. Every cue records the semantic evidence,
exact anchor word/index/time, intent, type, content, layout, bounds, motion policy,
asset, and score.

## QA gate

`graphics-qa.json` separates machine checks from delivery readiness. A clean
plan sets `automatedChecksPassed: true`, but `readiness.readyForDelivery` remains
false until both the visual-composition and export-playback reviews are complete.
Those reviews explicitly cover trigger-frame legibility, caption clearance,
speaker/asset framing, decoded motion, audio sync, boundary frames, and current
mobile UI overlays.

Automated QA covers:

- Cue and anchor times inside the composition.
- Exact frame quantization.
- No unintended cue overlap.
- Graphic and speaker bounds inside the platform safe area.
- No speaker/graphic collision.
- No caption-region collision.
- Headline density and repeated-layout warnings.
- Missing selected assets.
- Platform graphic-time density budget.
- Nondeterministic/infinite motion primitives.
- Unverified speaker crops (warning plus per-cue and composition metadata).

QA errors block `write_project()`. Warnings remain visible for editorial review.
Transcript-only planning cannot verify a face or subject crop, so every generated
speaker window stays `unverified` until the required visual export review. A
machine pass is never represented as final readiness. HyperFrames lint is the
second automated gate and validates the emitted composition.

## Tests

```powershell
python -m unittest discover `
  -s "Editing_OS/Video Editing/Engines/Graphics_engine" `
  -p "test_*.py" -v
```

The suite covers transcript formats, overlap/end-bound rejection, clause
phrasing, trigger-deadline reveals, exact number anchoring, truthful proportions,
reference-like layout rhythm, deterministic plans, caption-aligned safe fractions
at custom/2x resolutions, local asset selection/staging, direct-root source media,
real MP4 asset transcoding plus HyperFrames lint, QA/readiness separation,
speaker-crop warnings, offline output, the legacy API, and QA rejection.

For the render contract, also lint a generated project:

```powershell
cd C:\hf_render\graphics-01
npx hyperframes lint
npx hyperframes snapshot . --at 2
```

## Boundaries

- This engine expects word-perfect alignment from the caption/transcription seam;
  it does not invent timing from raw text.
- It plans graphics after the footage cleanup pass. Dead-space and filler removal
  must happen first so cue times match the final edit.
- Caption rendering is separate; this engine only reserves and validates the
  caption region.
- Color grading is separate. The theme affects graphics, not the footage grade.

## Related pages

- [[Projects/Personal projects/AI Projects/Video editing tools/Editing_OS/Video Editing/Engines/README|Video Editing OS Engines]]
- [[Projects/Personal projects/AI Projects/Video editing tools/Editing_OS/Video Editing/Engines/Captions_engine/README|Captions Engine]]
- [[Projects/Personal projects/AI Projects/Video editing tools/Editing_OS/Video Editing/Engines/Video editing engine/README|Video Editing Engine]]
